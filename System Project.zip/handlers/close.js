// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { Events, EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder, PermissionFlagsBits } = require("discord.js");
const { Database } = require('st.db');
const db = new Database('/Json-db/Bots/ticketDB');
const confirme = "** Are you sure you want to close the ticket**";
const discordTranscripts = require('discord-html-transcripts');
module.exports = (client7) => {
    client7.on(Events.InteractionCreate, async (interaction) => {
        if (!interaction.isButton()) return;
        const { customId, channel, guild, user } = interaction;
        const ticketKey = `TICKET-PANEL_${channel.id}`;
        const Ticket = db.get(ticketKey);
        if (customId === 'close') {
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('Yes11').setLabel('Close').setStyle(ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('No11').setLabel('Cancel').setStyle(ButtonStyle.Secondary),
                );
            await interaction.reply({ content: confirme, components: [row] });
        } 
        else if (customId === 'Yes11') {
            if (!Ticket) return interaction.reply({ content: "**Error: Ticket data was not found in the database.**", ephemeral: true });
            await interaction.deferUpdate();
            try {
    const member = await interaction.guild.members.fetch(Ticket.author).catch(() => null);
    if (member) {
        await channel.permissionOverwrites.edit(Ticket.author, { ViewChannel: false });
    } else {
        console.log("The ticket holder has left the server; the permissions modification has been bypassed.");
    }
} catch (err) {
    if (err.code !== 10009) {
        console.error("**Failed to modify the shutdown permissions.**", err);
    }
}
            const embed2 = new EmbedBuilder()
                .setDescription(`**Ticket closed by ${user}**`)
                .setColor("FF0000");
            const embed = new EmbedBuilder()
                .setDescription("```Support team panel.```")
                .setColor("FF0000");
            const roww = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('delete').setLabel('Delete').setStyle(ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('Open').setLabel('Open').setStyle(ButtonStyle.Success),
                    new ButtonBuilder().setCustomId('Tran').setLabel('Transcript').setStyle(ButtonStyle.Secondary),
                );
            await interaction.editReply({ 
                content: '', 
                embeds: [embed2, embed], 
                components: [roww] 
            });
            const Logs = db.get(`LogsRoom_${guild.id}`);
            const logChannel = guild.channels.cache.get(Logs);
            if (logChannel) {
                const embedLog = new EmbedBuilder()
                    .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL() })
                    .setTitle('Close Ticket')
                    .addFields(
                        { name: `Name Ticket`, value: `${channel.name}` },
                        { name: `Owner Ticket`, value: `<@${Ticket.author}>` },
                        { name: `Close BY`, value: `${user}` },
                    )
                    .setFooter({ text: user.tag, iconURL: user.displayAvatarURL() });
                logChannel.send({ embeds: [embedLog] }).catch(() => {});
            }
        } 
        else if (customId === 'No11') {
            await interaction.deferUpdate();
            await interaction.deleteReply();
        } 
        else if (customId === 'delete') {
            await interaction.reply({ content: `**#${channel.name} The channel will be deleted in 5 seconds...**`, ephemeral: true });
            const Logs = db.get(`LogsRoom_${guild.id}`);
            const logChannel = guild.channels.cache.get(Logs);
            if (logChannel) {
                const embedLog = new EmbedBuilder()
                    .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL() })
                    .setTitle('Delete Ticket')
                    .addFields(
                        { name: `Name Ticket`, value: `${channel.name}` },
                        { name: `Owner Ticket`, value: Ticket ? `<@${Ticket.author}>` : "Unknown" },
                        { name: `Delete BY`, value: `${user}` },
                    )
                    .setFooter({ text: user.tag, iconURL: user.displayAvatarURL() });
                logChannel.send({ embeds: [embedLog] }).catch(() => {});
            }
            setTimeout(async () => {
                db.delete(ticketKey);
                await channel.delete().catch(() => {});
            }, 5000);
        } 
        else if (customId === 'Open') {
            if (!Ticket) return interaction.reply({ content: "**Data error.**", ephemeral: true });
            
            await channel.permissionOverwrites.create(Ticket.author, { ViewChannel: true });
            await interaction.reply({ content: "**The ticket has been successfully reopened.**", ephemeral: true });
        } 
        else if (customId === 'Tran') {
            await interaction.deferReply({ ephemeral: true });
            const attachment = await discordTranscripts.createTranscript(channel);
            const Logs = db.get(`LogsRoom_${guild.id}`);
            const Trans = db.get(`TransRoom_${guild.id}`);
            const logChannel = guild.channels.cache.get(Logs);
            const TransChannel = guild.channels.cache.get(Trans);
            if (!TransChannel) {
                return interaction.editReply({ content: "**The Room transcript is not selected in the settings.**" });
            }
            const embed = new EmbedBuilder()
                .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL() })
                .setTitle('Transcripted Ticket')
                .addFields(
                    { name: `Name Ticket`, value: `${channel.name}` },
                    { name: `Owner Ticket`, value: Ticket ? `<@${Ticket.author}>` : "Unknown" },
                    { name: `Transcript BY`, value: `${user}` },
                )
                .setFooter({ text: user.tag, iconURL: user.displayAvatarURL() });
            if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
            await TransChannel.send({ files: [attachment] });
            await interaction.editReply({ content: `**The report was extracted and sent to ${TransChannel}**` });
        }
    });
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM