// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { 
  Events, ButtonBuilder, ActionRowBuilder, ButtonStyle 
} = require("discord.js");
const { Database } = require("st.db");
const rolesDB = new Database("/Json-db/Bots/systemDB.json");
module.exports = (client27) => {
  client27.on(Events.InteractionCreate, async (interaction) => {
    if (interaction.isButton()) {
      const [prefix, guildId, roleId] = interaction.customId.split("_");
      if (prefix !== "getrole") return; 
      const role = interaction.guild.roles.cache.get(roleId);
      if (!role) {
        return interaction.reply({
          content: `**Sorry, this role does not exist..**`,
          ephemeral: true,
        });
      }
      const member = interaction.member;
      if (member.roles.cache.has(roleId)) {
        await member.roles.remove(roleId);
        await interaction.reply({
          content: `**Role removed ${role.name} From you.**`,
          ephemeral: true,
        });
      } else {
        await member.roles.add(roleId);
        await interaction.reply({
          content: `**You have been awarded the role ${role.name}!**`,
          ephemeral: true,
        });
      }
    }
  });
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM