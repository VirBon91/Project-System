// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const {
  SlashCommandBuilder,
  Events,
  ActivityType,
  ModalBuilder,
  TextInputStyle,
  EmbedBuilder,
  PermissionsBitField,
  ButtonStyle,
  TextInputBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  MessageComponentCollector,
  Embed,
} = require("discord.js");
const { Database } = require("st.db");
const applyDB = new Database("/Json-db/Bots/applyDB.json");
module.exports = (client27) => {
  client27.on(Events.InteractionCreate, async (interaction) => {
    if (interaction.isButton() && interaction.customId == "apply_accept") {
      const settings = applyDB.get(`apply_settings_${interaction.guild.id}`);
      let adminrole = settings.adminrole;
      let resultsroom = settings.resultsroom;
      if (!interaction.member.roles.cache.has(`${adminrole}`)) {
        return interaction.reply({
          content: `**You don't have permission to do this.**`,
          ephemeral: true,
        });
      }
      const receivedEmbed = interaction.message.embeds[0];
      const exampleEmbed = EmbedBuilder.from(receivedEmbed);
      const user = exampleEmbed.data.title;
      let user2 = interaction.guild.members.cache.find((us) => us.id == user);
      const findApply = await applyDB.get(`apply_${interaction.guild.id}`);
      let roleid = parseInt(findApply.roleid);
      let therole = await interaction.guild.roles.cache.find((ro) => ro.id == roleid);
      await user2.roles.add(therole).then(async () => {
          if (applyDB.get(`dm_${interaction.guild.id}`) === true) {
            const dm_embed = new EmbedBuilder()
              .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
              .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
              .setTitle("Application Accepted!")
              .setDescription(`**> Admin: ${interaction.user}**`)
              .setColor("FF0000");
            user2.send({ embeds: [dm_embed] }).catch(() => {});
          }
          let theresultsroom = interaction.guild.channels.cache.find((ch) => ch.id == resultsroom);
          let embed = new EmbedBuilder()
            .setTimestamp()
            .setColor("FF0000")
            .setTitle(`**Application Approved**`)
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setThumbnail(interaction.user.avatarURL({ dynamic: true }))
            .setDescription(`**Applicant: ${user2} \n Admin: ${interaction.user}**`);
          theresultsroom.send({ content: `${user2}`, embeds: [embed] });
          const accpet = new ButtonBuilder()
            .setCustomId(`apply_accept`)
            .setLabel(`Accepted`)
            .setEmoji("<:yes:1329437524048740442>")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true);
          const reject = new ButtonBuilder()
            .setCustomId(`apply_reject`)
            .setLabel(`Rejected`)
            .setEmoji("<:no:1329437729821560904>")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true);
          const reject_with_reason = new ButtonBuilder()
            .setCustomId(`apply_reject_with_reason`)
            .setLabel(`Rejected with Reason`)
            .setEmoji("<:lightup:1329973322967945256>")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true);
          const row = new ActionRowBuilder().addComponents(accpet, reject, reject_with_reason);
          interaction.reply({ content: `**The application has been successfully accepted.**` });
          interaction.message.edit({ components: [row] });
        })
        .catch((err) => {
          return interaction.reply({
            content: `Error: Please ensure the bot's role is higher than the target role.`,
            ephemeral: true,
          });
        });
    }
    if (interaction.customId == "modal_reject_with_reason") {
      const settings = applyDB.get(`apply_settings_${interaction.guild.id}`);
      let adminrole = settings.adminrole;
      let resultsroom = settings.resultsroom;
      if (!interaction.member.roles.cache.has(`${adminrole}`)) {
        return interaction.reply({
          content: `**You don't have permission to do this.**`,
          ephemeral: true,
        });
      }
      let reason = interaction.fields.getTextInputValue(`reason`);
      const receivedEmbed = interaction.message.embeds[0];
      const exampleEmbed = EmbedBuilder.from(receivedEmbed);
      const user = exampleEmbed.data.title;
      let user2 = interaction.guild.members.cache.find((us) => us.id == user);
      let theresultsroom = interaction.guild.channels.cache.find((ch) => ch.id == resultsroom);
      let embed = new EmbedBuilder()
        .setTimestamp()
        .setColor("FF0000")
        .setTitle(`**Application Rejected**`)
        .setDescription(`** Applicant: ${user2} \n Admin: ${interaction.user} \n\n Reason: \`${reason}\`**`)
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setThumbnail(interaction.user.avatarURL({ dynamic: true }));
      await theresultsroom.send({ embeds: [embed] });
      if (applyDB.get(`dm_${interaction.guild.id}`) === true) {
        const dm_embed = new EmbedBuilder()
          .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
          .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
          .setTitle("Application Rejected")
          .setDescription(`**> Admin: ${interaction.user}** \n **> Reason: ${reason}**`)
          .setColor("FF0000");
        user2.send({ embeds: [dm_embed] }).catch(() => {});
      }
      const accpet = new ButtonBuilder().setCustomId(`apply_accept`).setLabel(`Accepted`).setEmoji("<:yes:1329437524048740442>").setStyle(ButtonStyle.Success).setDisabled(true);
      const reject = new ButtonBuilder().setCustomId(`apply_reject`).setLabel(`Rejected`).setEmoji("<:no:1329437729821560904>").setStyle(ButtonStyle.Danger).setDisabled(true);
      const reject_with_reason = new ButtonBuilder().setCustomId(`apply_reject_with_reason`).setLabel(`Rejected with Reason`).setStyle(ButtonStyle.Danger).setEmoji("<:lightup:1329973322967945256>").setDisabled(true);
      const row = new ActionRowBuilder().addComponents(accpet, reject, reject_with_reason);
      interaction.reply({ content: `**The application has been successfully rejected.**` });
      interaction.message.edit({ components: [row] });
    }
    if (interaction.isButton() && interaction.customId == "apply_reject") {
      const settings = applyDB.get(`apply_settings_${interaction.guild.id}`);
      let adminrole = settings.adminrole;
      let resultsroom = settings.resultsroom;
      if (!interaction.member.roles.cache.has(`${adminrole}`)) {
        return interaction.reply({
          content: `**You don't have permission to do this.**`,
          ephemeral: true,
        });
      }
      const receivedEmbed = interaction.message.embeds[0];
      const exampleEmbed = EmbedBuilder.from(receivedEmbed);
      const user = exampleEmbed.data.title;
      let user2 = interaction.guild.members.cache.find((us) => us.id == user);
      let theresultsroom = interaction.guild.channels.cache.find((ch) => ch.id == resultsroom);
      let embed = new EmbedBuilder()
        .setTimestamp()
        .setColor("FF0000")
        .setTitle(`**Application Rejected**`)
        .setDescription(`**Applicant: ${user2} \n Admin: ${interaction.user}**`)
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setThumbnail(interaction.user.avatarURL({ dynamic: true }));
      await theresultsroom.send({ embeds: [embed] });
      if (applyDB.get(`dm_${interaction.guild.id}`) === true) {
        const dm_embed = new EmbedBuilder()
          .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
          .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
          .setTitle("Application Rejected")
          .setDescription(`**> Admin: ${interaction.user}**`)
          .setColor("FF0000");
        user2.send({ embeds: [dm_embed] }).catch(() => {});
      }
      const accpet = new ButtonBuilder().setCustomId(`apply_accept`).setLabel(`Accepted`).setEmoji("<:yes:1329437524048740442>").setStyle(ButtonStyle.Success).setDisabled(true);
      const reject = new ButtonBuilder().setCustomId(`apply_reject`).setLabel(`Rejected`).setEmoji("<:no:1329437729821560904>").setStyle(ButtonStyle.Danger).setDisabled(true);
      const reject_with_reason = new ButtonBuilder().setCustomId(`apply_reject_with_reason`).setLabel(`Rejected with Reason`).setStyle(ButtonStyle.Danger).setEmoji("<:lightup:1329973322967945256>").setDisabled(true);
      const row = new ActionRowBuilder().addComponents(accpet, reject, reject_with_reason);
      interaction.reply({ content: `**The application has been successfully rejected.**` });
      interaction.message.edit({ components: [row] });
    }
  });
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM