// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { StringSelectMenuOptionBuilder, StringSelectMenuBuilder, SlashCommandBuilder, Events, ActivityType, ModalBuilder, TextInputStyle, EmbedBuilder, PermissionsBitField, ButtonStyle, TextInputBuilder, ActionRowBuilder, ButtonBuilder, MessageComponentCollector, Embed } = require("discord.js")
const { Database } = require('st.db')
const dd = new Database('/Json-db/Bots/ticketDB')
const select = new StringSelectMenuBuilder()
    .setCustomId('supportPanel')
    .setPlaceholder('Support team Panel')
    .addOptions(
        new StringSelectMenuOptionBuilder().setLabel('Change the name of the ticket').setValue('renameTicket').setEmoji('<:maintenance:1329437473285345290>'),
        new StringSelectMenuOptionBuilder().setLabel('Add member to ticket').setValue('addMemberToTicket').setEmoji('<:yes:1329437524048740442>'),
        new StringSelectMenuOptionBuilder().setLabel('Delete member from ticket').setValue('removeMemberFromTicket').setEmoji('<:no:1329437729821560904>'),
        new StringSelectMenuOptionBuilder().setLabel('Reset Selection').setValue('refreshSupportPanel').setEmoji('<:backing:1329973325228675222>')
    )
const Row2 = new ActionRowBuilder().addComponents(select)
module.exports = (client7) => {
    client7.on(Events.InteractionCreate, async (interaction) => {
        if (interaction.isButton()) {
            const [action] = interaction.customId.split('_')
            if (action === 'claim') {
                const Support = dd.get(`TICKET-PANEL_${interaction.channel.id}`).Support
                if (!interaction.member.roles.cache.has(Support)) {
                    return interaction.reply({ content: `**Only Support**`, ephemeral: true })
                }
                dd.set(`Claimed_${interaction.channel.id}`, interaction.user.id)
                const Row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setStyle(ButtonStyle.Secondary).setLabel('Close').setCustomId(`close`),
                        new ButtonBuilder().setCustomId('55555555555').setStyle(ButtonStyle.Success).setDisabled().setEmoji('<:yes:1329437524048740442>').setLabel(`by ${interaction.user.username}`),
                        new ButtonBuilder().setCustomId('unclaim').setStyle(ButtonStyle.Primary).setLabel('UnClaimed')
                    )
                let claimembed = new EmbedBuilder()
                    .setDescription(`**${interaction.user} He Claimed the ticket**`)
                    .setColor(`FF0000`)
                await interaction.channel.permissionOverwrites.edit(Support, { SendMessages: false })
                await interaction.channel.permissionOverwrites.edit(interaction.user.id, { SendMessages: true })
                await interaction.deferUpdate()
                await interaction.editReply({ components: [Row, Row2] })
                await interaction.channel.send({ embeds: [claimembed] })
            } else if (action === 'unclaim') {
                if (dd.get(`Claimed_${interaction.channel.id}`) == interaction.user.id) {
                    const Support = dd.get(`TICKET-PANEL_${interaction.channel.id}`)?.Support
                    if (!interaction.member.roles.cache.has(Support)) {
                        return interaction.reply({ content: `**<:interdit:1329437847404412982> Only Support <:interdit:1329437847404412982>**`, ephemeral: true })
                    }
                    await interaction.channel.permissionOverwrites.edit(Support, { SendMessages: true })
                    await interaction.channel.permissionOverwrites.edit(interaction.user.id, { SendMessages: false })
                    let unclaimembed = new EmbedBuilder()
                        .setDescription(`**${interaction.user} Cancel ticket claiming**`)
                        .setColor(`FF0000`)
                    const Row = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setStyle(ButtonStyle.Secondary).setLabel('Close').setCustomId(`close`),
                            new ButtonBuilder().setStyle(ButtonStyle.Success).setLabel('Claim').setCustomId(`claim`)
                        )
                    await interaction.deferUpdate()
                    await interaction.editReply({ components: [Row, Row2] })
                    return interaction.channel.send({ embeds: [unclaimembed] })
                } else {
                    return interaction.reply({ content: `**The ticket is not for you**`, ephemeral: true })
                }
            }
        }
    })
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM