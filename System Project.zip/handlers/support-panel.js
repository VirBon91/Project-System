// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { ChatInputCommandInteraction , Client , SlashCommandBuilder,Events , ActivityType,ModalBuilder,TextInputStyle, EmbedBuilder , PermissionsBitField,ButtonStyle, TextInputBuilder, ActionRowBuilder,ButtonBuilder,MessageComponentCollector, Embed } = require("discord.js");
const { Database } = require("st.db")
const dd = new Database("/Json-db/Bots/ticketDB.json")
const discordTranscripts = require('discord-html-transcripts');
module.exports = (client27 , interaction) => {
  client27.on(Events.InteractionCreate , async(interaction) =>{
    if(interaction.isStringSelectMenu()) {
      if(interaction.customId === "supportPanel"){
          let selected = await dd.get(`${interaction.channel.id}`)
         const Support = dd.get(`TICKET-PANEL_${interaction.channel.id}`).Support;
          if (!interaction.member.roles.cache.has(Support)) return interaction.reply({content:`**You do not have the authority to do this.**` , ephemeral:true})
          if(interaction.values[0] === "renameTicket"){
                const modal = new ModalBuilder().setTitle('Change the name of the ticket').setCustomId('renameTicketSubmitModal');
                const newNameInp = new TextInputBuilder().setCustomId('newNameValue').setLabel('New ticket name').setStyle(TextInputStyle.Short).setRequired(true);
                const inpRow = new ActionRowBuilder().addComponents(newNameInp);
                modal.addComponents(inpRow);
                await interaction.showModal(modal);
          }else if(interaction.values[0] === "addMemberToTicket"){
              const modal = new ModalBuilder().setTitle('Add member to ticket').setCustomId('addMemberToTicketSubmitModal');
              const memberIdInp = new TextInputBuilder().setCustomId('addMemberToTicketMemberId').setLabel('Member ID').setStyle(TextInputStyle.Short).setRequired(true);
              const inpRow = new ActionRowBuilder().addComponents(memberIdInp);
              modal.addComponents(inpRow);
              await interaction.showModal(modal);
          }else if(interaction.values[0] === "removeMemberFromTicket"){
            const modal = new ModalBuilder().setTitle('Delete member from ticket').setCustomId('removeMemberFromTicketSubmitModal');
            const memberIdInp = new TextInputBuilder().setCustomId('removeMemberFromTicketMemberId').setLabel('Member ID').setStyle(TextInputStyle.Short).setRequired(true);
            const inpRow = new ActionRowBuilder().addComponents(memberIdInp);
            modal.addComponents(inpRow);
            await interaction.showModal(modal);
          }else if(interaction.values[0] === "refreshSupportPanel"){
              try {
                return await interaction.update().catch(async() => {return;})
              } catch  {
                return;
              }
          }
          
      }
    }
    if(interaction.isModalSubmit()){
        if(interaction.customId == "renameTicketSubmitModal"){
            const newName = interaction.fields.getTextInputValue('newNameValue');
            await interaction.reply({embeds : [new EmbedBuilder().setColor('FF0000').setDescription(`**The name of the ticket has been changed to \`${newName}\`**`).setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})}).setFooter({text : `Requested by : ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})]})
            await interaction.update().catch(async() => {return;})
            await interaction.channel.setName(newName)
        }else if(interaction.customId == "addMemberToTicketSubmitModal"){
          const memberId = interaction.fields.getTextInputValue('addMemberToTicketMemberId');
          const theMember = await client27.users.fetch(memberId)
          if(theMember){
            await interaction.reply({embeds : [new EmbedBuilder().setColor('FF0000').setDescription(`**Added \`${theMember.username}\` To the ticket**`).setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})}).setFooter({text : `Requested by : ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})]})
            await interaction.update().catch(async() => {return;})
            await interaction.channel.permissionOverwrites.edit(theMember.id , {
              ViewChannel: true,
              SendMessages: true
            })
          }else{
            await interaction.reply({embeds : [new EmbedBuilder().setColor('FF0000').setDescription(`**Sorry, I couldn't find a member with these hands. \`${memberId}\`**`).setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})}).setFooter({text : `Requested by : ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})] , ephemeral : true})
            await interaction.update().catch(async() => {return;})
          }
        }else if(interaction.customId == "removeMemberFromTicketSubmitModal"){
          const memberId = interaction.fields.getTextInputValue('removeMemberFromTicketMemberId');
            const theMember = await client27.users.fetch(memberId).catch(() => {return;})
          if(theMember){
            await interaction.reply({embeds : [new EmbedBuilder().setColor('FF0000').setDescription(`**Deleted \`${theMember.username}\` From the ticket**`).setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})}).setFooter({text : `Requested by : ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})]})
            await interaction.update().catch(async() => {return;})
            await interaction.channel.permissionOverwrites.edit(theMember.id , {
              ViewChannel: false,
              SendMessages: false
            })
          }else{
            await interaction.reply({embeds : [new EmbedBuilder().setColor('FF0000').setDescription(`**Sorry, I couldn't find a member with these hands. \`${memberId}\`**`).setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})}).setFooter({text : `Requested by : ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})] , ephemeral : true})
            await interaction.update().catch(async() => {return;})
          }
        }
    }
  }
  )}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM