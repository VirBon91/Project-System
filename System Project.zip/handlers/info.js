// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { Events } = require("discord.js");
const { Database } = require('st.db');
const buttonsDB = new Database("/Json-db/Bots/systemDB.json");
module.exports = (client27) => {
  client27.on(Events.InteractionCreate, async (interaction) => {
    if (interaction.isButton()) {
      if (!interaction.customId.startsWith('info_')) return;

      let [, buttonId] = interaction.customId.split('_'); 

      try {
        const guildId = interaction.guild.id;
        const savedMessage = await buttonsDB.get(`${guildId}_${buttonId}`);

        if (savedMessage) {
          await interaction.reply({ content: savedMessage, ephemeral: true });
        } else {
          await interaction.reply({ content: '**No message was found associated with this button.**', ephemeral: true });
        }
      } catch (error) {
        console.error(error);
        await interaction.reply({ content: '**An error occurred, or the message is too long.**', ephemeral: true });
      }
    }
  });
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM