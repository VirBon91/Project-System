// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder,Events ,Client, ActivityType,ModalBuilder,TextInputStyle, EmbedBuilder , PermissionsBitField,ButtonStyle, TextInputBuilder, ActionRowBuilder,ButtonBuilder,MessageComponentCollector } = require("discord.js");
const { Database } = require("st.db");
const suggestionsDB = new Database("/Json-db/Bots/suggestionsDB.json")
module.exports = (client27) => {
  client27.on(Events.InteractionCreate , async(interaction) =>{
    if(interaction.isButton()) {
        if(interaction.customId == "ok_button") {
            const themsg = interaction.message;
            if(suggestionsDB.has(`${themsg.id}_${interaction.user.id}_voted`)) return interaction.reply({content:`**I have already voted once**` , ephemeral:true})
            let oks = suggestionsDB.get(`${themsg.id}_ok`)
            let nos = suggestionsDB.get(`${themsg.id}_no`)
            oks = oks + 1
            const button1 = new ButtonBuilder()
    .setCustomId(`ok_button`)
    .setLabel(`${oks}`)
    .setEmoji("<:yes:1329437524048740442>")
    .setStyle(ButtonStyle.Success)
    const button2 = new ButtonBuilder()
    .setCustomId(`no_button`)
    .setLabel(`${nos}`)
    .setEmoji("<:no:1329437729821560904>")
    .setStyle(ButtonStyle.Danger)
    const row = new ActionRowBuilder().addComponents(button1 , button2)
    await suggestionsDB.set(`${themsg.id}_ok` , oks)
    await interaction.reply({content:`**Thank you for your vote**` , ephemeral:true})
    await suggestionsDB.set(`${themsg.id}_${interaction.user.id}_voted` , true)
    return interaction.message.edit({components:[row]})
        }
        if(interaction.customId == "no_button") {
            const themsg = interaction.message;
        if(suggestionsDB.has(`${themsg.id}_${interaction.user.id}_voted`)) return interaction.reply({content:`**I have already voted once**` , ephemeral:true})
            let oks = suggestionsDB.get(`${themsg.id}_ok`)
            let nos = suggestionsDB.get(`${themsg.id}_no`)
            nos = nos + 1
            const button1 = new ButtonBuilder()
    .setCustomId(`ok_button`)
    .setLabel(`${oks}`)
    .setEmoji("<:yes:1329437524048740442>")
    .setStyle(ButtonStyle.Success)
    const button2 = new ButtonBuilder()
    .setCustomId(`no_button`)
    .setLabel(`${nos}`)
    .setEmoji("<:no:1329437729821560904>")
    .setStyle(ButtonStyle.Danger)
    const row = new ActionRowBuilder().addComponents(button1 , button2)
    await suggestionsDB.set(`${themsg.id}_no` , nos)
    await interaction.reply({content:`**Thank you for your vote**` , ephemeral:true})
    await suggestionsDB.set(`${themsg.id}_${interaction.user.id}_voted` , true)
    return interaction.message.edit({components:[row]})
        }
    }
  }
  )};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM