// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { Database } = require("st.db");
const db = new Database('/Json-db/Bots/ticketDB');
const { 
    StringSelectMenuOptionBuilder,
    StringSelectMenuBuilder,
    SlashCommandBuilder,
    Events,
    ActivityType,
    ModalBuilder,
    TextInputStyle,
    EmbedBuilder,
    PermissionsBitField,
    ButtonStyle,
    TextInputBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    MessageComponentCollector,
    Embed
} = require("discord.js");
module.exports = (client27) => {
    client27.on(Events.InteractionCreate, async (interaction) => {
        if ((interaction.isButton() || interaction.isStringSelectMenu()) && interaction.customId.startsWith('ticket')) {
            const customId = interaction.isStringSelectMenu() ? interaction.values[0] : interaction.customId;
        if (customId === 'reset') {
            return; 
        }
            const data = db.get(`Ticket_${interaction.channel.id}_${customId}`);
            if (!data) return interaction.reply({ content: `**Please Setup Again.**`, ephemeral: true });
            if (data.Ask === 'on') {
                const modal = new ModalBuilder()
                    .setCustomId(customId + '_modal')
                    .setTitle('The reason for opening the ticket')
                    .addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('ticket_reason')
                                .setLabel('What is the reason for opening the ticket?')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                        )
                    );
                await interaction.showModal(modal);
            } else {
                createTicketChannel(interaction, data);
            }
        }
        if (interaction.isModalSubmit() && interaction.customId.endsWith('_modal')) {
            const buttonCustomId = interaction.customId.replace('_modal', '');
            const data = db.get(`Ticket_${interaction.channel.id}_${buttonCustomId}`);
            if (!data) return interaction.reply({ content: `**Please Setup Again.**`, ephemeral: true });
            const ticketReason = interaction.fields.getTextInputValue('ticket_reason');
            createTicketChannel(interaction, data, ticketReason);
        }

    });
};
async function createTicketChannel(interaction, data, ticketReason = null) {
    const channel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username}`,
        type: 0,
        parent: data.Category,
        permissionOverwrites: [
            {
                id: interaction.guild.roles.everyone.id,
                deny: ['ViewChannel'],
            },
            {
                id: data.Support,
                allow: ['ViewChannel', 'SendMessages'],
            },
            {
                id: interaction.user.id,
                allow: ['ViewChannel', 'SendMessages'],
            },
        ],
    });
    db.set(`TICKET-PANEL_${channel.id}`, { author: interaction.user.id, Support: data.Support });
    interaction.reply({ content: `**${channel} has been created**`, ephemeral: true });
    const embed = new EmbedBuilder()
        .setColor('FF0000')
        .setDescription(`${data.Internal}`)
        .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();
    const select = new StringSelectMenuBuilder()
        .setCustomId('supportPanel')
        .setPlaceholder('Support team Panel')
        .addOptions(
            new StringSelectMenuOptionBuilder()
                .setLabel('Change the name of the ticket')
                .setValue('renameTicket')
                .setEmoji('<:maintenance:1329437473285345290>🏼'),
            new StringSelectMenuOptionBuilder()
                .setLabel('Add member to ticket')
                .setValue('addMemberToTicket')
                .setEmoji('<:yes:1329437524048740442>'),
            new StringSelectMenuOptionBuilder()
                .setLabel('Delete member from ticket')
                .setValue('removeMemberFromTicket')
                .setEmoji('<:no:1329437729821560904>'),
            new StringSelectMenuOptionBuilder()
                .setLabel('Reset Selection')
                .setValue('refreshSupportPanel')
                .setEmoji('<:backing:1329973325228675222>'),
        );
    const row2 = new ActionRowBuilder().addComponents(select);
    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder().setCustomId('close').setLabel('Close').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('claim').setLabel('Claim').setStyle(ButtonStyle.Success)
        );
    if (data.Type === 'embed') {
        await channel.send({ 
            content: `${interaction.user},<@&${data.Support}>`, 
            embeds: [embed], 
            components: [row, row2] 
        });
    } else {
        await channel.send({ 
            content: `${interaction.user},<@&${data.Support}>\n${data.Internal}`, 
            components: [row, row2] 
        });
    }
    if (ticketReason) {
        const reasonEmbed = new EmbedBuilder()
            .setColor('FF0000')
            .setDescription(`**The reason for opening the ticket : \`\`\` ${ticketReason} \`\`\`**`)
            .setTimestamp();
        
        await channel.send({ embeds: [reasonEmbed] });
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM