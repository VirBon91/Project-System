// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { Client, Collection, discord, ComponentType, GatewayIntentBits, ChannelType, AuditLogEvent, Partials, EmbedBuilder, ApplicationCommandOptionType, Events, ActionRowBuilder, ButtonBuilder, MessageAttachment, ButtonStyle, Message, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js");
const moment = require('moment');
const ms = require('ms')
const fs = require('fs');
const { Database } = require("st.db")
const taxDB = new Database("/Json-db/Bots/taxDB.json")
const autolineDB = new Database("/Json-db/Bots/autolineDB.json")
const suggestionsDB = new Database("/Json-db/Bots/suggestionsDB.json")
const feedbackDB = new Database("/Json-db/Bots/feedbackDB.json")
const giveawayDB = new Database("/Json-db/Bots/giveawayDB.json")
const systemDB = new Database("/Json-db/Bots/systemDB.json")
const shortcutDB = new Database("/Json-db/Others/shortcutDB.json")
const protectDB = new Database("/Json-db/Bots/protectDB.json")
const db = new Database("/Json-db/Bots/BroadcastDB")
const logsDB = new Database("/Json-db/Bots/logsDB.json")
const nadekoDB = new Database("/Json-db/Bots/nadekoDB.json")
const one4allDB = new Database("/Json-db/Bots/one4allDB.json")
const ticketDB = new Database("/Json-db/Bots/ticketDB.json")
const path = require('path');
const { readdirSync } = require("fs");
  const { REST } = require('@discordjs/rest');
  const { Routes } = require('discord-api-types/v10');
const { token, clientId,owner, prefix } = require('./config.js');
  theowner = owner;
  const client27 = new Client({intents: 131071 , shards: "auto", partials: [Partials.Message, Partials.Channel, Partials.GuildMember,]});
  client27.commands = new Collection();
  require(`./handlers/events`)(client27);
  client27.events = new Collection();
  const rest = new REST({ version: '10' }).setToken(token);
  client27.setMaxListeners(1000)
  client27.on("clientReady" , async() => {
    try {
        await rest.put(
            Routes.applicationCommands(client27.user.id),
            { body: one4allSlashCommands },
        );
    } catch (error) {
        console.error(error)
    }
});
    client27.once('clientReady', () => {
    client27.guilds.cache.forEach(guild => {
        guild.members.fetch().then(members => {
            if (members.size < 10) {
                console.log(`VirBon Bot : Guild: ${guild.name} has less than 10 members`);
            }
        }).catch(console.error);
    });
});
    require(`./handlers/events`)(client27)
    require("./handlers/suggest")(client27)
    require('./handlers/tax4bot')(client27)
    require("./handlers/autorole")(client27)
    require(`./handlers/events`)(client27);
    require(`./handlers/claim`)(client27);
    require(`./handlers/close`)(client27);
    require(`./handlers/create`)(client27);
    require(`./handlers/reset`)(client27);
    require(`./handlers/support-panel`)(client27);
    require('./handlers/joinGiveaway')(client27)
    require(`./handlers/events`)(client27)
    require(`./handlers/applyCreate`)(client27)
    require(`./handlers/applyResult`)(client27)
    require(`./handlers/applySubmit`)(client27)
    require(`./handlers/events`)(client27)
    require(`./handlers/addToken`)(client27)
    require(`./handlers/info`)(client27)
    require(`./handlers/sendBroadcast`)(client27)
    require(`./handlers/setBroadcastMessage`)(client27)
  const folderPath = path.join(__dirname, 'slashcommand27');
  client27.one4allSlashCommands = new Collection();
  const one4allSlashCommands = [];
  const ascii = require("ascii-table");
  const table = new ascii("one4all commands").setJustify();
  for (let folder of readdirSync(folderPath).filter(
    (folder) => !folder.includes(".")
    )) {
      for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
      f.endsWith(".js")
      )) {
        let command = require(`${folderPath}/${folder}/${file}`);
        if (command) {
          one4allSlashCommands.push(command.data.toJSON());
          client27.one4allSlashCommands.set(command.data.name, command);
          if (command.data.name) {
            table.addRow(`/${command.data.name}`, "🟢 Working");
          } else {
            table.addRow(`/${command.data.name}`, "🔴 Not Working");
          }
        }
  }
}
const folderPath2 = path.join(__dirname, 'slashcommand27');
for(let foldeer of readdirSync(folderPath2).filter((folder) => !folder.includes("."))) {
  for(let fiee of(readdirSync(`${folderPath2}/${foldeer}`).filter((fi) => fi.endsWith(".js")))) {
    const commander = require(`${folderPath2}/${foldeer}/${fiee}`)
  }
}
require("./handlers/events")(client27)
	for (let file of readdirSync('./events/').filter(f => f.endsWith('.js'))) {
		const event = require(`./events/${file}`);
	if (event.once) {
		client27.once(event.name, (...args) => event.execute(...args));
	} else {
		client27.on(event.name, (...args) => event.execute(...args));
	}
	}
  client27.on("interactionCreate" , async(interaction) => {
    if (interaction.isChatInputCommand()) { 
        if(interaction.user.bot) return;
        const command = client27.one4allSlashCommands.get(interaction.commandName);
        
        if (!command) {
            return;
        }
        if (command.ownersOnly === true) {
            if (owner != interaction.user.id) {
                return interaction.reply({content: `**You cannot use this command.**`, flags: [MessageFlags.Ephemeral]});
            }
        }
        if (command.adminsOnly === true) {
            if (!interaction.guild) {
                return interaction.reply({ content: "**This is only available within servers..**", flags: [MessageFlags.Ephemeral]});
            }
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return interaction.reply({ 
                    content: `**Sorry, you do not have the required permissions to use this command.**`, 
                    flags: [MessageFlags.Ephemeral] 
                });
            }
        }
        try {
            await command.execute(interaction);
        } catch (error) {
            return console.log("Error in System bot" , error)
        }
    }
} )
process.on('uncaughtException', (err) => {
  console.log(err)
});
process.on('unhandledRejection', (reason, promise) => {
 console.log(reason)
});
 process.on("uncaughtExceptionMonitor", (reason) => { 
    console.log(reason)
});
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM

//-

// -- Giveaways -- \\
client27.on("clientReady" , async() => {
    let theguild = client27.guilds.cache.first();
    setInterval(() => {
        if(!theguild) return;
        let giveaways = giveawayDB.get(`giveaways_${theguild.id}`)
        if(!giveaways) return;
        giveaways.forEach(async(giveaway) => {
            let {messageid , channelid , entries , winners , prize , duration,dir1,dir2,ended} = giveaway;
            if(duration > 0) {
                duration = duration - 1
                giveaway.duration = duration;
                await giveawayDB.set(`giveaways_${theguild.id}` , giveaways)
            }else if(duration == 0) {
                duration = duration - 1
                giveaway.duration = duration;
                await giveawayDB.set(`giveaways_${theguild.id}` , giveaways)
                const theroom = theguild.channels.cache.find(ch => ch.id == channelid)
                await theroom.messages.fetch(messageid)
                const themsg = await theroom.messages.cache.find(msg => msg.id == messageid)
                if(entries.length > 0 && entries.length >= winners) {
                    const theWinners = [];
                    for(let i = 0; i < winners; i++) {
                        let winner = Math.floor(Math.random() * entries.length);
                        let winnerExcept = entries.splice(winner, 1)[0];
                        theWinners.push(winnerExcept);
                    }
                    const button = new ButtonBuilder()
                        .setLabel(`🎉`)
                        .setStyle(ButtonStyle.Secondary)
                        .setCustomId(`join_giveaway`)
                        .setDisabled(true)
                    const row = new ActionRowBuilder().addComponents(button)
                    themsg.edit({components:[row]})
                    themsg.reply({content:`Congratulations ${theWinners}! You won the **${prize}**!`})
                    giveaway.ended = true;
                    await giveawayDB.set(`giveaways_${theguild.id}` , giveaways)
                }else{
                    const button = new ButtonBuilder()
                        .setLabel(`🎉`)
                        .setStyle(ButtonStyle.Secondary)
                        .setCustomId(`join_giveaway`)
                        .setDisabled(true)
                    const row = new ActionRowBuilder().addComponents(button)
                    themsg.edit({components:[row]})
                    themsg.reply({content:`**There are not enough participants.**`})
                    giveaway.ended = true;
                    await giveawayDB.set(`giveaways_${theguild.id}` , giveaways)
                }
            }
        })
    }, 1000);
})
// -- Giveaways -- \\

//-

// -- Tax -- \\
client27.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!message.guild) return;
  let roomid = taxDB.get(`tax_room_${message.guild.id}`);
  let taxLine = taxDB.get(`tax_line_${message.guild.id}`);
  let taxMode = taxDB.get(`tax_mode_${message.guild.id}`) || 'embed'; 
  let taxColor = taxDB.get(`tax_color_${message.guild.id}`) || '#FF0000'; 
  if (roomid) {
    if (message.channel.id === roomid) {
      if (message.author.bot) return;
      let number = message.content;
      if (number.endsWith("k")) number = number.replace(/k/gi, "") * 1000;
      else if (number.endsWith("K")) number = number.replace(/K/gi, "") * 1000;
      else if (number.endsWith("m")) number = number.replace(/m/gi, "") * 1000000;
      else if (number.endsWith("M")) number = number.replace(/M/gi, "") * 1000000;
      if (isNaN(number) || number == 0) return message.delete();
      let number2 = parseInt(number);
      let tax = Math.floor(number2 * 20 / 19 + 1);
      let tax2 = Math.floor(tax - number2);
      let tax3 = Math.floor(tax * 20 / 19 + 1);
      let tax4 = Math.floor(number2 * 0.02);
      let tax5 = Math.floor(tax3 + tax4);
      let description = `
- Amount **: ${number2}**
- ProBot Tax **: ${tax}**
- Total Amount with Broker Tax **: ${tax3}**
- Broker's 2% Commission **: ${tax4}**
- Total Tax with Broker's Commission **: ${tax5}**
`;
      let btn1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`tax_${tax}`)
          .setLabel('Tax')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId(`mediator_${tax5}`)
          .setLabel('Mediator')
          .setStyle(ButtonStyle.Secondary)
      );
      if (taxMode === 'embed') {
        let embed1 = new EmbedBuilder()
          .setColor(taxColor)
          .setDescription(description)
          .setThumbnail(message.guild.iconURL({ dynamic: true }));
        message.reply({ embeds: [embed1], components: [btn1] });
        if (taxLine) {
          message.channel.send({ files: [taxLine] });
        }
      } else {
        message.reply({ content: description, components: [btn1] });

        if (taxLine) {
          message.channel.send({ files: [taxLine] });
        }
      }
      return;
    }
  }
});
// -- Tax -- \\

//-

// -- Autoline -- \\
client27.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.guild) return;
  const line = autolineDB.get(`line_${message.guild.id}`);
  const lineMode = autolineDB.get(`line_mode_${message.guild.id}`) || 'image';
  if (message.content === "-" || message.content === "line") {
    if (line && message.member.permissions.has('ManageMessages')) {
      await message.delete();
      if (lineMode === 'link') {
        return message.channel.send({ content: `${line}` });
      } else if (lineMode === 'image') {
        return message.channel.send({ files: [line] });
      }
    }
  }
});
client27.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.guild) return;
  const autoChannels = autolineDB.get(`line_channels_${message.guild.id}`);
  if (autoChannels) {
    if (autoChannels.length > 0) {
      if (autoChannels.includes(message.channel.id)) {
        const line = autolineDB.get(`line_${message.guild.id}`);
        const lineMode = autolineDB.get(`line_mode_${message.guild.id}`) || 'image';
        if (line) {
          if (lineMode === 'link') {
            return message.channel.send({ content: `${line}` });
          } else if (lineMode === 'image') {
            return message.channel.send({ files: [line] });
          }
        }
      }
    }
  }
});
// -- Autoline -- \\

//-

// -- Broadcast -- \\
client27.on('messageCreate', async message => {
  if (message.author.bot) return;
if (message.content.startsWith(`${prefix}obc`) || message.content.startsWith(`${prefix}bc`)) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply('**Sorry, you do not have the required permissions to use this command.**');
    }
    const args = message.content.split(' ').slice(1);
    const broadcastMsg = args.join(' ');
    if (!broadcastMsg) {
      return message.reply('**Please write a message after the order.**');
    }
    await message.guild.members.fetch();
    let allMembers = message.guild.members.cache.filter(member => !member.user.bot);
    if (message.content.startsWith(`${prefix}obc`)) {
      allMembers = allMembers.filter(mem =>
        mem.presence?.status === 'online' ||
        mem.presence?.status === 'dnd' ||
        mem.presence?.status === 'idle' ||
        mem.presence?.activities.some(activity => activity.type === ActivityType.Streaming)
      );
    }
    allMembers = allMembers.map(mem => mem.user.id);
    const thetokens = db.get(`tokens_${message.guild.id}`) || [];
    const botsNum = thetokens.length;
    const membersPerBot = Math.floor(allMembers.length / botsNum);
    const submembers = [];
    for (let i = 0; i < allMembers.length; i += membersPerBot) {
      submembers.push(allMembers.slice(i, i + membersPerBot));
    }
    if (submembers.length > botsNum) {
      submembers.pop();
    }
    let donemembers = 0;
    let faildmembers = 0;
    const embed = new EmbedBuilder()
      .setTitle('Start sending the broadcast')
      .setColor('FF0000')
      .setDescription(`**Number of members: \`${allMembers.length}\`\nSent to: \`${donemembers}\`\nFailed to send to: \`${faildmembers}\`**`);
    const msg = await message.channel.send({ embeds: [embed] });
    for (let i = 0; i < submembers.length; i++) {
      const token = thetokens[i];
      let clienter = new Client({ intents: 131071 });
      await clienter.login(token);
      submembers[i].forEach(async (sub) => {
        try {
          const user = await clienter.users.fetch(sub);
          await user.send(`${broadcastMsg}\n<@${sub}>`);
          donemembers++;
        } catch (error) {
          faildmembers++;
        }
        const progressEmbed = new EmbedBuilder()
          .setTitle('Broadcast status update')
          .setColor('FF0000')
          .setDescription(`**Number of members: \`${allMembers.length}\`\nSent to: \`${donemembers}\`\nFailed to send to: \`${faildmembers}\`**`);
        await msg.edit({ embeds: [progressEmbed] });
        if (donemembers + faildmembers >= allMembers.length) {
          const finalEmbed = new EmbedBuilder()
            .setTitle('The broadcast has been sent.')
            .setColor('FF0000')
            .setDescription(`**Number of members: \`${allMembers.length}\`\nSent to: \`${donemembers}\`\nFailed to send to: \`${faildmembers}\`**`);
          await msg.edit({ embeds: [finalEmbed] });
        }
      });
    }
  }
});
// -- Broadcast -- \\

//-

// -- Rate Staffs -- \\
client27.on('messageCreate', async message => {
    if (!message.guild) return;
const cmd = await shortcutDB.get(`rate_cmd_${message.guild.id}`) || null;  
    if (message.author.bot) return;
  if (message.content === `${prefix}rate` || message.content === `${cmd}`) {
        const stafer = message.author;
        const staffRole = await feedbackDB.get(`staff_role_${message.guild.id}`);  
        if (!message.member.roles.cache.has(staffRole)) {
            return; 
        }
        const filter = response => !response.author.bot && response.author.id !== stafer.id;
        message.channel.send(`**Please write your evaluation of the staff. <@${stafer.id}>**`).then(() => {
            message.channel.awaitMessages({ filter, max: 1, errors: ['time'] })
                .then(async collected => {
                    const user = collected.first().author; 
                    const userText = collected.first().content;
                    const rankroom = feedbackDB.get(`rank_room_${message.guild.id}`);
                    const st1 = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId('1star').setLabel('1 Star').setStyle(ButtonStyle.Danger),
                            new ButtonBuilder().setCustomId('2star').setLabel('2 Stars').setStyle(ButtonStyle.Danger),
                            new ButtonBuilder().setCustomId('3star').setLabel('3 Stars').setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId('4star').setLabel('4 Stars').setStyle(ButtonStyle.Success),
                            new ButtonBuilder().setCustomId('5star').setLabel('5 Stars').setStyle(ButtonStyle.Success)
                        );
                    await message.channel.send({ content: 'Choose the number of stars:', components: [st1] });
                    const buttonFilter = i => !i.user.bot && i.user.id !== stafer.id;
                    const collector = message.channel.createMessageComponentCollector({ filter: buttonFilter, time: 60000 });
                    collector.on('collect', async interaction => {
                        if (!interaction.isButton()) return;
                        let embedDescription;
                        switch (interaction.customId) {
                            case '1star':
                                embedDescription = '1 Star';
                                break;
                            case '2star':
                                embedDescription = '2 Stars';
                                break;
                            case '3star':
                                embedDescription = '3 Stars';
                                break;
                            case '4star':
                                embedDescription = '4 Stars';
                                break;
                            case '5star':
                                embedDescription = '5 Stars';
                                break;
                        }
                        const embedrank = new EmbedBuilder()
                            .setDescription(`${userText}\n**Number of stars:**\n${embedDescription}`)
                            .setColor('FF0000')
                            .setAuthor({
                                name: user.username,
                                iconURL: user.displayAvatarURL()
                            });
                        const rankChannel = client27.channels.cache.get(rankroom);
                        if (rankChannel) {
                            await rankChannel.send({ content: `Staff: <@${stafer.id}>`, embeds: [embedrank] });
                            await interaction.reply({ content: '**Your review has been successfully submitted. Thank you for using our services.**', flags: [MessageFlags.Ephemeral] });
                        } else {
                            await interaction.reply({ content: '**An error occurred; the evaluation ROM does not exist.**', flags: [MessageFlags.Ephemeral] });
                        }
                            await interaction.message.delete();
                        collector.stop();
                    });
                    collector.on('end', collected => {
                        if (collected.size === 0) {
                            message.channel.send('**No reviews were received.**');
                        }
                    });
                })
                .catch(error => {
                    console.error('Error collecting messages: ', error);
                    message.channel.send('**Time up, you can t evaluate.**');
                });
        });
    }
});
// -- Rate Staffs -- \\

//-

// -- Suggestions -- \\
client27.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.guild) return;
  const line = suggestionsDB.get(`line_${message.guild.id}`);
  const chan = suggestionsDB.get(`suggestions_room_${message.guild.id}`);
  const suggestionMode = suggestionsDB.get(`suggestion_mode_${message.guild.id}`) || 'buttons';
  const threadMode = suggestionsDB.get(`thread_mode_${message.guild.id}`) || 'enabled';
  if (chan) {
    if (message.channel.id !== chan) return;
    const embed = new EmbedBuilder()
      .setColor('FF0000')
      .setTimestamp()
      .setTitle(`** > ${message.content} **`)
      .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
      .setAuthor({ name: message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL({ dynamic: true }) });
    if (suggestionMode === 'buttons') {
      const button1 = new ButtonBuilder()
        .setCustomId(`ok_button`)
        .setLabel(`Accept`)
        .setStyle(ButtonStyle.Success);
      const button2 = new ButtonBuilder()
        .setCustomId(`no_button`)
        .setLabel(`Deny`)
        .setStyle(ButtonStyle.Danger);
      const row = new ActionRowBuilder().addComponents(button1, button2);
      let send = await message.channel.send({ embeds: [embed], components: [row] }).catch(() => { return; });
      if (threadMode === 'enabled') {
        await send.startThread({
          name: `Comments - تعليقات`
        }).then(async (thread) => {
          thread.send(`** - This space is for sharing your opinion on this proposal: \`${message.content}\` **`);
        });
      }
      if (line) {
        await message.channel.send({ files: [line] }).catch((err) => { return; });
      }
      await suggestionsDB.set(`${send.id}_ok`, 0);
      await suggestionsDB.set(`${send.id}_no`, 0);
      return message.delete();
    } else if (suggestionMode === 'reactions') {
      let send = await message.channel.send({ embeds: [embed] }).catch(() => { return; });
      await send.react('✅');
      await send.react('❌');
      if (threadMode === 'enabled') {
        await send.startThread({
          name: `Comments - تعليقات`
        }).then(async (thread) => {
          thread.send(`** - This space is for sharing your opinion on this proposal: \`${message.content}\` **`);
        });
      }
      if (line) {
        await message.channel.send({ files: [line] }).catch((err) => { return; });
      }
      return message.delete();
    }
  }
});
// -- Suggestions -- \\

//-

// -- Feedback -- \\
client27.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.guild) return;
  const line = feedbackDB.get(`line_${message.guild.id}`);
  const chan = feedbackDB.get(`feedback_room_${message.guild.id}`);
  const feedbackMode = feedbackDB.get(`feedback_mode_${message.guild.id}`) || 'embed'; 
  const feedbackEmoji = feedbackDB.get(`feedback_emoji_${message.guild.id}`) || "❤"; 
  if (chan) {
    if (message.channel.id !== chan) return;
    const embed = new EmbedBuilder()
      .setColor('FF0000')
      .setTimestamp()
      .setTitle(`** > ${message.content} **`)
      .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
      .setAuthor({ name: message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL({ dynamic: true }) });
    if (feedbackMode === 'embed') {
      await message.delete();
      const themsg = await message.channel.send({ content: `**<@${message.author.id}> Thank you for sharing your opinion with us**`, embeds: [embed] });
      await themsg.react("❤");
      await themsg.react("❤️‍🔥");
      if (line) {
        await message.channel.send({ files: [line] });
      }
    } else if (feedbackMode === 'reactions') {
      await message.react(feedbackEmoji);
      if (line) {
        await message.channel.send({ files: [line] });
      }
    }
  }
});
// -- Feedback -- \\

//-

// -- Ticket -- \\
client27.on('messageCreate', async message => {
    if (!message.guild || message.author.bot) return;
    if (message.content === `${prefix}close`) {
        const ticket = ticketDB.get(`TICKET-PANEL_${message.channel.id}`);
        if (!ticket) {
            return message.reply({ content: '**This channel is not a ticket.**' });
        }
        try {
            await message.channel.permissionOverwrites.edit(ticket.author, { ViewChannel: false });
        } catch (err) {
            console.log("Could not remove user permissions (maybe left server).");
        }
        const embed2 = new EmbedBuilder()
            .setDescription(`**Ticket closed by ${message.author}**`)
            .setColor("FF0000");
        const embed = new EmbedBuilder()
            .setDescription("```Support team panel.```")
            .setColor("FF0000");
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId('delete').setLabel('Delete').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('Open').setLabel('Open').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('Tran').setLabel('Transcript').setStyle(ButtonStyle.Secondary)
            );
        await message.reply({ embeds: [embed2, embed], components: [row] });
        const logsRoomId = ticketDB.get(`LogsRoom_${message.guild.id}`);
        const logChannel = message.guild.channels.cache.get(logsRoomId);
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
                .setTitle('Close Ticket')
                .addFields(
                    { name: 'Name Ticket', value: `${message.channel.name}`, inline: true },
                    { name: 'Owner Ticket', value: `<@${ticket.author}>`, inline: true },
                    { name: 'Closed By', value: `${message.author}`, inline: true },
                )
                .setFooter({ text: message.author.tag, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();
            logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
    }
    if (message.content === `${prefix}delete`) {
        const ticket = ticketDB.get(`TICKET-PANEL_${message.channel.id}`);
        if (!ticket) {
            return message.reply({ content: '**This channel isn\'t a ticket**' });
        }
        const supportRoleId = ticket.Support;
        if (!message.member.roles.cache.has(supportRoleId) && !message.member.permissions.has('Administrator')) {
            return message.reply({ content: '**Only Support**' });
        }
        const embed = new EmbedBuilder()
            .setColor('FF0000')
            .setDescription('**Ticket will be deleted in a few seconds**');
        await message.reply({ embeds: [embed] });
        const Logs = ticketDB.get(`LogsRoom_${message.guild.id}`);
        const Log = message.guild.channels.cache.get(Logs);
        if (Log) {
            const logEmbed = new EmbedBuilder()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
                .setTitle('Delete Ticket')
                .addFields(
                    { name: 'Name Ticket', value: `${message.channel.name}`, inline: true },
                    { name: 'Owner Ticket', value: `<@${ticket.author}>`, inline: true },
                    { name: 'Deleted By', value: `${message.author}`, inline: true },
                )
                .setFooter({ text: message.author.tag, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();
            await Log.send({ embeds: [logEmbed] }).catch(() => {});
        }
        setTimeout(() => {
            message.channel.delete().catch(() => {});
            ticketDB.delete(`TICKET-PANEL_${message.channel.id}`);
        }, 4500);
    }
});
// -- Ticket -- \\

//-

// -- Say -- \\
client27.on('messageCreate', async message => {
    if (!message.guild) return;
const cmd = await shortcutDB.get(`say_cmd_${message.guild.id}`) || null;  
    if (message.author.bot) return;
    if (message.content.startsWith(`${prefix}say`) || message.content.startsWith(`${cmd}`)) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return;
        const content = message.content.slice(`${prefix}say`.length).trim();
        if (!content) {
            message.channel.send("**Please write something after the command.**");
            return;
        }
        let image = null;
        if (message.attachments.size > 0) {
            const attachment = message.attachments.first();
            image = attachment.url;
        }
        await message.delete();
        await message.channel.send({ 
            content: content, 
            files: image ? [image] : [] 
        });
    }
});
// -- Say -- \\

//-

// -- Clear -- \\
client27.on('messageCreate', async message => {
    if (!message.guild) return;
  const cmd = shortcutDB.get(`clear_cmd_${message.guild.id}`) || null;
    if (message.author.bot) return;
    if (message.content.startsWith(`${prefix}clear`) || message.content.startsWith(`${cmd}`)) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return;
        const args = message.content.split(' ').slice(1);
        const amount = args[0] ? parseInt(args[0]) : 99;
        if (isNaN(amount) || amount <= 0 || amount > 100) return;
        try {
            const fetchedMessages = await message.channel.messages.fetch({ limit: amount });
            const messagesToDelete = fetchedMessages.filter(msg => {
                const fourteenDays = 14 * 24 * 60 * 60 * 1000;
                return (Date.now() - msg.createdTimestamp) < fourteenDays;
            });
            await message.channel.bulkDelete(messagesToDelete);
        } catch (error) {
        }
    }
});
// -- Clear -- \\

//-

// -- Tax -- \\
client27.on('messageCreate', async message => {
    if (!message.guild) return;
const cmd = await shortcutDB.get(`tax_cmd_${message.guild.id}`) || null; 
    if (message.content.startsWith(`${prefix}tax`) || message.content.startsWith(`${cmd}`)) {
        const args = message.content.startsWith(`${prefix}tax`) 
            ? message.content.slice(`${prefix}tax`.length).trim() 
            : message.content.slice(`${cmd}`.length).trim();
        let number = args;
        if (number.endsWith("k")) number = number.replace(/k/gi, "") * 1000;
        else if (number.endsWith("K")) number = number.replace(/K/gi, "") * 1000;
        else if (number.endsWith("m")) number = number.replace(/m/gi, "") * 1000000;
        else if (number.endsWith("M")) number = number.replace(/M/gi, "") * 1000000;
        let number2 = parseFloat(number);
        if (isNaN(number2)) {
            return message.reply('**Please enter a valid number after the command.**');
        }
        let tax = Math.floor(number2 * (20) / (19) + 1);
        let tax2 = Math.floor(tax - number2);
        await message.reply(`${tax}`);
    }
});
// -- Tax -- \\

//-

// -- Come -- \\
client27.on('messageCreate', async message => {
    if (!message.guild || message.author.bot) return;
    const cmd = await shortcutDB.get(`come_cmd_${message.guild.id}`) || null;
    if (message.content.startsWith(`${prefix}come`) || (cmd && message.content.startsWith(cmd))) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply({
                content: '**You do not have the authority to do that.**'
            });
        }
        const args = message.content.split(/\s+/);
        const targetMember = message.mentions.members.first() || message.guild.members.cache.get(args[1]);
        if (!targetMember) {
            return message.reply('**Please tag someone or provide their ID.**');
        }
        try {
            const channelLink = `https://discord.com/channels/${message.guild.id}/${message.channel.id}`;
            const dmEmbed = new EmbedBuilder()
                .setTitle('Notice')
                .setDescription(`**You have been summoned by staff.**`)
                .addFields(
                    { name: 'By Admin:', value: `${message.author}`, inline: true },
                    { name: 'Server:', value: `${message.guild.name}`, inline: true },
                    { name: 'Channel:', value: `${message.channel}`, inline: true }
                )
                .setColor('#FF0000')
                .setFooter({ text: 'Please join as soon as possible' })
                .setTimestamp();
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Join Channel')
                        .setStyle(ButtonStyle.Link)
                        .setURL(channelLink)
                );
            await targetMember.send({
                content: `${targetMember}`,
                embeds: [dmEmbed], 
                components: [row] 
            });
            const successEmbed = new EmbedBuilder()
                .setDescription(`**Successfully summoned ${targetMember} to this channel.**`)
                .setColor('#FF0000');
            await message.reply({ embeds: [successEmbed] });
        } catch (error) {
            console.error(error);
            await message.reply('**Could not DM this user. Their DMs might be closed.**');
        }
    }
});
// -- Come -- \\

//-

// -- Lock -- \\
client27.on("messageCreate", async (message) => {
    if (!message.guild) return;
const cmd = await shortcutDB.get(`lock_cmd_${message.guild.id}`) || null;  
  if (message.content === `${prefix}lock` || message.content === `${cmd}`) {
    try {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return message.reply({ content: `**You do not have the authority to do that.**` });
            }
      await message.channel.permissionOverwrites.edit(
        message.channel.guild.roles.everyone, 
        { SendMessages: false }
      );
      return message.reply({ content: `**${message.channel} has been locked**` });
    } catch (error) {
      message.reply({ content: `**An error occurred, please contact the developers.**` });
      console.log(error);
    }
  }
});
// -- Lock -- \\

//-

// -- Unlock -- \\
client27.on("messageCreate", async (message) => {
    if (!message.guild) return;
const cmd = await shortcutDB.get(`unlock_cmd_${message.guild.id}`) || null;  
  if (message.content === `${prefix}unlock` || message.content === `${cmd}`) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({ content: `**You do not have the authority to do that.**` });
    }
      await message.channel.permissionOverwrites.edit(
      message.channel.guild.roles.everyone, 
      { SendMessages: true }
    );
    return message.reply({ content: `**${message.channel} has been unlocked**` });
  }
});
// -- Unlock -- \\

//-

// -- Hide -- \\
client27.on("messageCreate", async (message) => {
if (!message.guild) return;
const cmd = await shortcutDB.get(`hide_cmd_${message.guild.id}`) || null;  
  if (message.content === `${prefix}hide` || message.content === `${cmd}`) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({ content: `**You do not have the authority to do that.**` });
    }
      await message.channel.permissionOverwrites.edit(
      message.channel.guild.roles.everyone, 
      { ViewChannel: false }
    );
    return message.reply({ content: `**${message.channel} has been hidden**` });
  }
});
// -- Hide -- \\

//-

// -- Unhide -- \\
client27.on("messageCreate", async (message) => {
if (!message.guild) return;
const cmd = await shortcutDB.get(`unhide_cmd_${message.guild.id}`) || null;  
  if (message.content === `${prefix}unhide` || message.content === `${cmd}`) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({ content: `**You do not have the authority to do that.**` });
    }
      await message.channel.permissionOverwrites.edit(
      message.channel.guild.roles.everyone, 
      { ViewChannel: true }
    );
    return message.reply({ content: `**${message.channel} has been unhidded**` });
  }
});
// -- Unhide -- \\

//-

// -- Server -- \\
client27.on("messageCreate", async (message) => {
    if (!message.guild) return; 
    const cmd = await shortcutDB.get(`server_cmd_${message.guild.id}`) || null;
    if (message.content === `${prefix}server` || message.content === `${cmd}`) {
    const embedser = new EmbedBuilder()
      .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL({ dynamic: true }) })
      .setColor('FF0000')
      .addFields(
        {
          name: `**Server ID:**`, 
          value: message.guild.id, 
          inline: false
        },
        {
          name: `**Created On:**`, 
          value: `**<t:${parseInt(message.guild.createdTimestamp / 1000)}:R>**`, 
          inline: false
        },
        {
          name: `**Owned By:**`, 
          value: `**<@${message.guild.ownerId}>**`, 
          inline: false
        },
        {
          name: `**Members (${message.guild.memberCount})**`, 
          value: `**${message.guild.premiumSubscriptionCount} Boosts**`, 
          inline: false
        },
        {
          name: `**Channels (${message.guild.channels.cache.size})**`, 
          value: `**${message.guild.channels.cache.filter(r => r.type === ChannelType.GuildText).size}** Text | **${
              message.guild.channels.cache.filter(r => r.type === ChannelType.GuildVoice).size
            }** Voice | **${message.guild.channels.cache.filter(r => r.type === ChannelType.GuildCategory).size}** Category`,
          inline: false
        },
        {
          name: 'Others',
          value: `**Verification Level:** ${message.guild.verificationLevel}`,
          inline: false
        }
      )
      .setThumbnail(message.guild.iconURL({ dynamic: true }));
    return message.reply({ embeds: [embedser] });
  }
});
// -- Server -- \\

//-

// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM

//-

// بداية الحماية من البوتات
client27.on("guildMemberAdd" , async(member) => {
  if(protectDB.has(`antibots_status_${member.guild.id}`)) {
    let antibotsstatus = protectDB.get(`antibots_status_${member.guild.id}`)
    if(antibotsstatus == "on") {
      if(member.user.bot) {
        try {
          const logRoom = await protectDB.get(`protectLog_room_${member.guild.id}`)
          if(logRoom){
            const theLogRoom = await member.guild.channels.cache.find((ch) => ch.id == logRoom);
            theLogRoom.send({embeds : [new EmbedBuilder().setTitle('Protection system').addFields({name : `Member :` , value : `${member.user.username} \`${member.id}\``} , {name : `Reason :` , value : `Bot protection system`} , {name : `Punishment :` , value : `Kick the bot`})]})
          }
          member.kick()
        } catch(err){
          return console.log('error' , err);
        }
      }
    }
  }
})
// نهاية الحماية من البوتات

//-

// بداية الحماية من حذف الرومات
client27.on('clientReady' , async() => {
  const guild = client27.guilds.cache.first()
  if(!guild) return;
  const guildid = guild.id
  let status = protectDB.get(`antideleterooms_status_${guildid}`)
  if(!status)return;
  if(status == "off") return;
  setInterval(() => {
  const users = protectDB.get(`roomsdelete_users_${guildid}`)
    if(!users) return;
    if(users.length > 0) {
      users.forEach(async(user) => {
        const { userid , limit , newReset } = user;
        const currentTime = moment().format('YYYY-MM-DD');
        if(moment(currentTime).isSame(newReset) || moment(currentTime).isAfter(newReset)) {
          const newResetDate = moment().add(1 , 'day').format('YYYY-MM-DD')
          executordb = {userid:userid,limit:0,newReset:newResetDate}
          const index = users.findIndex(user => user.userid === userid);
      users[index] = executordb;
      await protectDB.set(`roomsdelete_users_${guildid}` , users)
        }
        let limitrooms = protectDB.get(`antideleterooms_limit_${guildid}`)
      if(limit > limitrooms) {
        let member = guild.members.cache.find(m => m.id == userid)
       try {
         member.kick()
       } catch  {
        return;
       }
      }
      })
      
    } 
  }, 6 * 1000);
})
client27.on('channelDelete' , async(channel) => {
  let guildid = channel.guild.id
  let status = protectDB.get(`antideleterooms_status_${guildid}`)
  if(!status)return;
  if(status == "off") return;
  const fetchedLogs = await channel.guild.fetchAuditLogs({
    limit: 1,
    type: AuditLogEvent.ChannelDelete
  });
  const channelDeleteLog = fetchedLogs.entries.first();
  const { executor } = channelDeleteLog;
  const users = protectDB.get(`roomsdelete_users_${guildid}`)
  const endTime = moment().add(1 , 'day').format('YYYY-MM-DD')
  if(users.length <= 0) {
    await protectDB.push(`roomsdelete_users_${guildid}` , {userid:executor.id , limit:1 , newReset:endTime})
    return;
  }
  let executordb = users.find(user => user.userid == executor.id)
  if(!executordb) {
      await protectDB.push(`roomsdelete_users_${guildid}` , {userid:executor.id , limit:1 , newReset:endTime})
      return;
  }
  let oldexecutorlimit = executordb.limit
  let newexecutorlimit = oldexecutorlimit + 1
  executordb = {userid:executor.id,limit:newexecutorlimit,newReset:endTime}
  const index = users.findIndex(user => user.userid === executor.id);
users[index] = executordb;
  let deletelimit = protectDB.get(`antideleterooms_limit_${guildid}`)
  if(newexecutorlimit > deletelimit) {
    let guild = client27.guilds.cache.find(gu => gu.id == guildid)
    let member = guild.members.cache.find(ex => ex.id == executor.id)
   try {
    const logRoom = await protectDB.get(`protectLog_room_${member.guild.id}`)
    if(logRoom){
      const theLogRoom = await member.guild.channels.cache.find((ch) => ch.id == logRoom);
      theLogRoom.send({embeds : [new EmbedBuilder().setTitle('Protection system').addFields({name : `Member :` , value : `${member.user.username} \`${member.id}\``} , {name : `Reason :` , value : `Delete Channels`} , {name : `Punishment :` , value : `Kick the member`})]})
    }
    member.kick()
   } catch  {
    return;
   }
    let filtered = users.filter(a => a.userid != executor.id)
    await protectDB.set(`roomsdelete_users_${guildid}` , filtered)
  } else {
    await protectDB.set(`roomsdelete_users_${guildid}` , users)
  }
})
// نهاية الحماية من حذف الرومات

//-

// بداية الحماية من حذف الرتب
client27.on('clientReady' , async() => {
  const guild = client27.guilds.cache.first()
  if(!guild) return;
  const guildid = guild.id
  let status = protectDB.get(`antideleteroles_status_${guildid}`)
  if(!status)return;
  if(status == "off") return;
  setInterval(() => {
  const users = protectDB.get(`rolesdelete_users_${guildid}`)
    if(!users) return;
    if(users.length > 0) {
      users.forEach(async(user) => {
        const { userid , limit , newReset } = user;
        const currentTime = moment().format('YYYY-MM-DD');
        if(moment(currentTime).isSame(newReset) || moment(currentTime).isAfter(newReset)) {
          const newResetDate = moment().add(1 , 'day').format('YYYY-MM-DD')
          executordb = {userid:userid,limit:0,newReset:newResetDate}
          const index = users.findIndex(user => user.userid === userid);
      users[index] = executordb;
      await protectDB.set(`rolesdelete_users_${guildid}` , users)
        }
        let limitrooms = protectDB.get(`antideleteroles_limit_${guildid}`)
      if(limit > limitrooms) {
        let member = guild.members.cache.find(m => m.id == userid)
       try {
         member.kick()
       } catch  {
        return;
       }
      }
      })
    } 
  }, 6 * 1000);
})

client27.on('roleDelete' , async(role) => {
  let guildid = role.guild.id
  let status = protectDB.get(`antideleteroles_status_${guildid}`)
  if(!status)return;
  if(status == "off") return;
  const fetchedLogs = await role.guild.fetchAuditLogs({
    limit: 1,
    type: AuditLogEvent.ChannelDelete
  });
  const channelDeleteLog = fetchedLogs.entries.first();
  const { executor } = channelDeleteLog;
  const users = protectDB.get(`rolesdelete_users_${guildid}`)
  const endTime = moment().add(1 , 'day').format('YYYY-MM-DD')
  if(users.length <= 0) {
    await protectDB.push(`rolesdelete_users_${guildid}` , {userid:executor.id , limit:1 , newReset:endTime})
    return;
  }
  let executordb = users.find(user => user.userid == executor.id)
  if(!executordb) {
      await protectDB.push(`rolesdelete_users_${guildid}` , {userid:executor.id , limit:1 , newReset:endTime})
      return;
  }
  let oldexecutorlimit = executordb.limit
  let newexecutorlimit = oldexecutorlimit + 1
  executordb = {userid:executor.id,limit:newexecutorlimit,newReset:endTime}
  const index = users.findIndex(user => user.userid === executor.id);
users[index] = executordb;
  let deletelimit = protectDB.get(`antideleteroles_limit_${guildid}`)
  if(newexecutorlimit > deletelimit) {
    let guild = client27.guilds.cache.find(gu => gu.id == guildid)
    let member = guild.members.cache.find(ex => ex.id == executor.id)
   try {
    const logRoom = await protectDB.get(`protectLog_room_${member.guild.id}`)
    if(logRoom){
      const theLogRoom = await member.guild.channels.cache.find((ch) => ch.id == logRoom);
      theLogRoom.send({embeds : [new EmbedBuilder().setTitle('Protection system').addFields({name : `Member :` , value : `${member.user.username} \`${member.id}\``} , {name : `Reason :` , value : `Delete Role`} , {name : `Punishment :` , value : `Kick the member`})]})
    }
    member.kick()
   } catch  {
    return;
   }
    let filtered = users.filter(a => a.userid != executor.id)
    await protectDB.set(`rolesdelete_users_${guildid}` , filtered)
  } else {
    await protectDB.set(`rolesdelete_users_${guildid}` , users)
  }
})
// نهاية الحماية من حذف الرتب

//-

// بداية الحماية من البان
client27.on('clientReady' , async() => {
  const guild = client27.guilds.cache.first()
  if(!guild) return;
  const guildid = guild.id
  let status = protectDB.get(`ban_status_${guildid}`)
  if(!status)return;
  if(status == "off") return;
  setInterval(() => {
  const users = protectDB.get(`ban_users_${guildid}`)
    if(!users) return;
    if(users.length > 0) {
      users.forEach(async(user) => {
        const { userid , limit , newReset } = user;
        const currentTime = moment().format('YYYY-MM-DD');
        if(moment(currentTime).isSame(newReset) || moment(currentTime).isAfter(newReset)) {
          const newResetDate = moment().add(1 , 'day').format('YYYY-MM-DD')
          executordb = {userid:userid,limit:0,newReset:newResetDate}
          const index = users.findIndex(user => user.userid === userid);
      users[index] = executordb;
      await protectDB.set(`ban_users_${guildid}` , users)
        }
        let limitrooms = protectDB.get(`ban_limit_${guildid}`)
      if(limit > limitrooms) {
        let member = guild.members.cache.find(m => m.id == userid)
       try {
         member.kick()
       } catch  {
        return;
       }
      }
      })
    } 
  }, 6 * 1000);
})
client27.on('guildBanAdd' , async(member) => {
  let guildid = member.guild.id
  let status = protectDB.get(`ban_status_${guildid}`)
  if(!status)return;
  if(status == "off") return;
  const fetchedLogs = await member.guild.fetchAuditLogs({
    limit: 1,
    type: AuditLogEvent.MemberBanAdd
  });
  const channelDeleteLog = fetchedLogs.entries.first();
  const { executor } = channelDeleteLog;
  const users = protectDB.get(`ban_users_${guildid}`)
  const endTime = moment().add(1 , 'day').format('YYYY-MM-DD')
  if(users.length <= 0) {
    await protectDB.push(`ban_users_${guildid}` , {userid:executor.id , limit:1 , newReset:endTime})
    return;
  }
  let executordb = users.find(user => user.userid == executor.id)
  if(!executordb) {
      await protectDB.push(`ban_users_${guildid}` , {userid:executor.id , limit:1 , newReset:endTime})
      return;
  }
  let oldexecutorlimit = executordb.limit
  let newexecutorlimit = oldexecutorlimit + 1
  executordb = {userid:executor.id,limit:newexecutorlimit,newReset:endTime}
  const index = users.findIndex(user => user.userid === executor.id);
users[index] = executordb;
  let deletelimit = protectDB.get(`ban_limit_${guildid}`)
  if(newexecutorlimit > deletelimit) {
    let guild = client27.guilds.cache.find(gu => gu.id == guildid)
    let member = guild.members.cache.find(ex => ex.id == executor.id)
   try {
    const logRoom = await protectDB.get(`protectLog_room_${member.guild.id}`)
    if(logRoom){
      const theLogRoom = await member.guild.channels.cache.find((ch) => ch.id == logRoom);
      theLogRoom.send({embeds : [new EmbedBuilder().setTitle('Protection system').addFields({name : `Member :` , value : `${member.user.username} \`${member.id}\``} , {name : `Reason :` , value : `Ban Member`} , {name : `Punishment :` , value : `Kick the member`})]})
    }
    member.kick()
   } catch  {
    return;
   }
    let filtered = users.filter(a => a.userid != executor.id)
    await protectDB.set(`ban_users_${guildid}` , filtered)
  } else {
    await protectDB.set(`ban_users_${guildid}` , users)
  }
})
client27.on('guildMemberRemove' , async(member) => {
  let guildid = member.guild.id
  let status = protectDB.get(`ban_status_${guildid}`)
  if(!status)return;
  if(status == "off") return;
  if(member.id === client27.user.id) return;
  const fetchedLogs = await member.guild.fetchAuditLogs({
    limit: 1,
    type: AuditLogEvent.MemberKick
  });
  const channelDeleteLog = fetchedLogs.entries.first();
  const { executor } = channelDeleteLog;
  const users = protectDB.get(`ban_users_${guildid}`)
  const endTime = moment().add(1 , 'day').format('YYYY-MM-DD')
  if(users.length <= 0) {
    await protectDB.push(`ban_users_${guildid}` , {userid:executor.id , limit:1 , newReset:endTime})
    return;
  }
  let executordb = users.find(user => user.userid == executor.id)
  if(!executordb) {
      await protectDB.push(`ban_users_${guildid}` , {userid:executor.id , limit:1 , newReset:endTime})
      return;
  }
  let oldexecutorlimit = executordb.limit
  let newexecutorlimit = oldexecutorlimit + 1
  executordb = {userid:executor.id,limit:newexecutorlimit,newReset:endTime}
  const index = users.findIndex(user => user.userid === executor.id);
users[index] = executordb;
  let deletelimit = protectDB.get(`ban_limit_${guildid}`)
  if(newexecutorlimit > deletelimit) {
    let guild = client27.guilds.cache.find(gu => gu.id == guildid)
    let member = guild.members.cache.find(ex => ex.id == executor.id)
   try {
    const logRoom = await protectDB.get(`protectLog_room_${member.guild.id}`)
    if(logRoom){
      const theLogRoom = await member.guild.channels.cache.find((ch) => ch.id == logRoom);
      theLogRoom.send({embeds : [new EmbedBuilder().setTitle('Protection system').addFields({name : `Member :` , value : `${member.user.username} \`${member.id}\``} , {name : `Reason :` , value : `Kick Member`} , {name : `Punishment :` , value : `Kick the member`})]})
    }
    member.kick()
   } catch  {
    return;
   }
    let filtered = users.filter(a => a.userid != executor.id)
    await protectDB.set(`ban_users_${guildid}` , filtered)
  } else {
    await protectDB.set(`ban_users_${guildid}` , users)
  }
})
// نهاية الحماية من البان

//-

// بداية لوغ حذف الرسائل
client27.on('messageDelete' , async(message) => {
  if(!message) return;
  if(!message.author) return;
  if(message.author.bot) return;
if (!logsDB.has(`log_messagedelete_${message.guild.id}`)) return;
let deletelog1 = logsDB.get(`log_messagedelete_${message.guild.id}`)
  let deletelog2 = message.guild.channels.cache.get(deletelog1)
  const fetchedLogs = await message.guild.fetchAuditLogs({
    limit: 1,
    type: AuditLogEvent.MessageDelete
  });
  const deletionLog = fetchedLogs.entries.first();
  const { executor, target } = deletionLog;
let deleteembed = new EmbedBuilder()
.setTitle(`**Message deleted**`)
    .addFields(
      {
        name: `**The author of the message : **`, value: `**\`\`\`${message.author.tag} - (${message.author.id})\`\`\`**`, inline: false
      },
      {
        name: `**Delete the message : **`, value: `**\`\`\`${executor.username} - (${executor.id})\`\`\`**`, inline: false
      },
      {
        name: `**Message content : **`, value: `**\`\`\`${message.content}\`\`\`**`, inline: false
      },
      {
        name: `**The Room in which the deletion occurred : **`, value: `${message.channel}`, inline: false
      }
    )
    .setTimestamp();
  await deletelog2.send({ embeds: [deleteembed] })
})
// نهاية لوغ حذف الرسائل

//-

// بداية لوغ تعديل الرسائل
client27.on('messageUpdate' , async(oldMessage, newMessage) => {
if(!oldMessage.author) return;
if(oldMessage.author.bot) return;
if (!logsDB.has(`log_messageupdate_${oldMessage.guild.id}`)) return;
const fetchedLogs = await oldMessage.guild.fetchAuditLogs({
limit: 1,
type: AuditLogEvent.MessageUpdate
});
let updateLog1 = logsDB.get(`log_messageupdate_${oldMessage.guild.id}`);
  let updateLog2 = oldMessage.guild.channels.cache.get(updateLog1); 
const updateLog = fetchedLogs.entries.first();
const { executor } = updateLog;
let updateEmbed = new EmbedBuilder()
.setTitle(`**Message has been edited**`)
.addFields(
{
  name: "**The author of the message:**",
  value: `**\`\`\`${oldMessage.author.tag} (${oldMessage.author.id})\`\`\`**`,
  inline: false
},
{
  name: "**Old content:**",
  value: `**\`\`\`${oldMessage.content}\`\`\`**`,
  inline: false
},
{
  name: "**New content:**",
  value: `**\`\`\`${newMessage.content}\`\`\`**`,
  inline: false
},
{
  name: "**The Room that was updated:**",
  value: `${oldMessage.channel}`,
  inline: false
}
)
.setTimestamp()
await updateLog2.send({ embeds: [updateEmbed] });
})
// نهاية لوغ تعديل الرسائل

//-

// بداية لوغ انشاء الرتب
client27.on('roleCreate' , async(role) => {
if (!logsDB.has(`log_rolecreate_${role.guild.id}`)) return;
let roleCreateLog1 = logsDB.get(`log_rolecreate_${role.guild.id}`);
  let roleCreateLog2 = role.guild.channels.cache.get(roleCreateLog1);
  const fetchedLogs = await role.guild.fetchAuditLogs({
    limit: 1,
    type: AuditLogEvent.RoleCreate
  });
  const roleCreateLog = fetchedLogs.entries.first();
  const { executor } = roleCreateLog;
  let roleCreateEmbed = new EmbedBuilder()
    .setTitle('**Role created**')
    .addFields(
      { name: 'Role name:', value: `\`\`\`${role.name}\`\`\``, inline: true },
      { name: 'Who created the role:', value: `\`\`\`${executor.username} (${executor.id})\`\`\``, inline: true }
    )
    .setTimestamp();
  await roleCreateLog2.send({ embeds: [roleCreateEmbed] });
})
// نهاية لوغ انشاء رتبة

//-

// بداية لوغ حذف رتبة
client27.on('roleDelete' , async(role) => {
if (!logsDB.has(`log_roledelete_${role.guild.id}`)) return;
let roleDeleteLog1 = logsDB.get(`log_roledelete_${role.guild.id}`);
  let roleDeleteLog2 = role.guild.channels.cache.get(roleDeleteLog1);
  const fetchedLogs = await role.guild.fetchAuditLogs({
    limit: 1,
    type: AuditLogEvent.RoleDelete
  });
  const roleDeleteLog = fetchedLogs.entries.first();
  const { executor } = roleDeleteLog;
  let roleDeleteEmbed = new EmbedBuilder()
    .setTitle('**Role removed**')
    .addFields({name:'Role name:', value:`\`\`\`${role.name}\`\`\``, inline:true},{name:'Who removed the role:', value:`\`\`\`${executor.username} (${executor.id})\`\`\``, inline:true})
    .setTimestamp();
  await roleDeleteLog2.send({ embeds: [roleDeleteEmbed] });
})
// نهاية لوغ حذف رتبة

//-

// بداية لوغ انشاء روم
client27.on('channelCreate', async (channel) => {
if (logsDB.has(`log_channelcreate_${channel.guild.id}`)) {
let channelCreateLog1 = logsDB.get(`log_channelcreate_${channel.guild.id}`);
let channelCreateLog2 = channel.guild.channels.cache.get(channelCreateLog1);
const fetchedLogs = await channel.guild.fetchAuditLogs({
  limit: 1,
  type: AuditLogEvent.ChannelCreate
});
const channelCreateLog = fetchedLogs.entries.first();
const { executor } = channelCreateLog;
let channelCategory = channel.parent ? channel.parent.name : 'None';
let channelCreateEmbed = new EmbedBuilder()
  .setTitle('**Room created**')
  .addFields(
    { name: 'The name of the room : ', value: `\`\`\`${channel.name}\`\`\``, inline: true },
    { name: 'Room Category : ', value: `\`\`\`${channelCategory}\`\`\``, inline: true },
    { name: 'Who creating the Room: ', value: `\`\`\`${executor.username} (${executor.id})\`\`\``, inline: true }
  )
  .setTimestamp();
await channelCreateLog2.send({ embeds: [channelCreateEmbed] });
}
});
// نهاية لوغ انشاء روم

//-

// بداية لوغ حذف روم
client27.on('channelDelete', async (channel) => {
if (logsDB.has(`log_channeldelete_${channel.guild.id}`)) {
let channelDeleteLog1 = logsDB.get(`log_channeldelete_${channel.guild.id}`);
let channelDeleteLog2 = channel.guild.channels.cache.get(channelDeleteLog1);
const fetchedLogs = await channel.guild.fetchAuditLogs({
  limit: 1,
  type: AuditLogEvent.ChannelDelete
});
const channelDeleteLog = fetchedLogs.entries.first();
const { executor } = channelDeleteLog;
let channelDeleteEmbed = new EmbedBuilder()
  .setTitle('**Room deleted**')
  .addFields(
    { name: 'The name of the Room: ', value: `\`\`\`${channel.name}\`\`\``, inline: true },
    { name: 'Who deleted the Room: ', value: `\`\`\`${executor.username} (${executor.id})\`\`\``, inline: true }
  )
  .setTimestamp();
await channelDeleteLog2.send({ embeds: [channelDeleteEmbed] });
}
});
// نهاية لوغ حذف روم

//-

// بدالة لوغ اعطاء و ازالة رول
client27.on('guildMemberUpdate', async (oldMember, newMember) => {
const guild = oldMember.guild;
const addedRoles = newMember.roles.cache.filter((role) => !oldMember.roles.cache.has(role.id));
const removedRoles = oldMember.roles.cache.filter((role) => !newMember.roles.cache.has(role.id));
if (addedRoles.size > 0 && logsDB.has(`log_rolegive_${guild.id}`)) {
let roleGiveLog1 = logsDB.get(`log_rolegive_${guild.id}`);
let roleGiveLog2 = guild.channels.cache.get(roleGiveLog1);
const fetchedLogs = await guild.fetchAuditLogs({
  limit: addedRoles.size,
  type: AuditLogEvent.MemberRoleUpdate
});
addedRoles.forEach((role) => {
  const roleGiveLog = fetchedLogs.entries.find((log) => log.target.id === newMember.id && log.changes[0].new[0].id === role.id);
  const roleGiver = roleGiveLog ? roleGiveLog.executor : null;
  const roleGiverUsername = roleGiver ? `${roleGiver.username} (${roleGiver.id})` : `UNKNOWN`;
  let roleGiveEmbed = new EmbedBuilder()
    .setTitle('**A role was given to a member**')
    .addFields(
      { name: 'Role name:', value: `\`\`\`${role.name}\`\`\``, inline: true },
      { name: 'It was given by:', value: `\`\`\`${roleGiverUsername}\`\`\``, inline: true },
      { name: 'It was given to the member:', value: `\`\`\`${newMember.user.username} (${newMember.user.id})\`\`\``, inline: true }
    )
    .setTimestamp();
  roleGiveLog2.send({ embeds: [roleGiveEmbed] });
});
}
if (removedRoles.size > 0 && logsDB.has(`log_roleremove_${guild.id}`)) {
let roleRemoveLog1 = logsDB.get(`log_roleremove_${guild.id}`);
let roleRemoveLog2 = guild.channels.cache.get(roleRemoveLog1);
const fetchedLogs = await guild.fetchAuditLogs({
  limit: removedRoles.size,
  type: AuditLogEvent.MemberRoleUpdate
});
removedRoles.forEach((role) => {
  const roleRemoveLog = fetchedLogs.entries.find((log) => log.target.id === newMember.id && log.changes[0].new[0].id === role.id);
  const roleRemover = roleRemoveLog ? roleRemoveLog.executor : null;
  const roleRemoverUsername = roleRemover ? `${roleRemover.username} (${roleRemover.id})` : `UNKNOWN`;
  let roleRemoveEmbed = new EmbedBuilder()
    .setTitle('**A member role was removed**')
    .addFields(
      { name: 'Role name:', value: `\`\`\`${role.name}\`\`\``, inline: true },
      { name: 'Removed by:', value: `\`\`\`${roleRemoverUsername}\`\`\``, inline: true },
      { name: 'Removed from member:', value: `\`\`\`${newMember.user.username} (${newMember.user.id})\`\`\``, inline: true }
    )
    .setTimestamp();
  roleRemoveLog2.send({ embeds: [roleRemoveEmbed] });
});
}
});
// نهاية لوغ اعطاء و ازالة رول

//-

// بداية لوغ اضافة بوت
client27.on('guildMemberAdd', async (member) => {
const guild = member.guild;
if(!member.bot) return;
const fetchedLogs = await guild.fetchAuditLogs({
limit: 1,
type: AuditLogEvent.BotAdd
});
const botAddLog = fetchedLogs.entries.first();
const { executor, target } = botAddLog;
if (target.bot) {
let botAddLog1 = logsDB.get(`log_botadd_${guild.id}`);
let botAddLog2 = guild.channels.cache.get(botAddLog1);
let botAddEmbed = new EmbedBuilder()
  .setTitle('**A new bot has been added to the server.**')
  .addFields(
    { name: 'Bot Name:', value: `\`\`\`${member.user.username}\`\`\``, inline: true },
    { name: 'Bot ID:', value: `\`\`\`${member.user.id}\`\`\``, inline: true },
    { name: 'Does he have administrator?:', value: member.permissions.has('Administrator') ? `\`\`\`Yes he has\`\`\`` : `\`\`\`No he doesn't have it\`\`\``, inline: true },
    { name: 'Added by:', value: `\`\`\`${executor.username} (${executor.id})\`\`\``, inline: false }
  )
  .setTimestamp();
botAddLog2.send({ embeds: [botAddEmbed] });
}
});
// نهاية لوغ اضافة بوت

//-

// بداية لوغ اعطاء بان
client27.on('guildBanAdd', async (guild, user) => {
if (logsDB.has(`log_banadd_${guild.id}`)) {
let banAddLog1 = logsDB.get(`log_banadd_${guild.id}`);
let banAddLog2 = guild.channels.cache.get(banAddLog1);
const fetchedLogs = await guild.fetchAuditLogs({
  limit: 1,
  type: AuditLogEvent.MemberBanAdd
});
const banAddLog = fetchedLogs.entries.first();
const banner = banAddLog ? banAddLog.executor : null;
const bannerUsername = banner ? `\`\`\`${banner.username} (${banner.id})\`\`\`` : `\`\`\`UNKNOWN\`\`\``;
let banAddEmbed = new EmbedBuilder()
  .setTitle('**Member has been banned**')
  .addFields(
    { name: 'Member banned:', value: `\`\`\`${user.tag} (${user.id})\`\`\`` },
    { name: 'Banned by:', value: bannerUsername },
  )
  .setTimestamp();
banAddLog2.send({ embeds: [banAddEmbed] });
}
});
// نهاية لوغ اعطاء بان

//-

// بداية لوغ ازالة بان
client27.on('guildBanRemove', async (guild, user) => {
if (logsDB.has(`log_bandelete_${guild.id}`)) {
let banRemoveLog1 = logsDB.get(`log_bandelete_${guild.id}`);
let banRemoveLog2 = guild.channels.cache.get(banRemoveLog1);
const fetchedLogs = await guild.fetchAuditLogs({
  limit: 1,
  type: AuditLogEvent.MemberBanRemove
});
const banRemoveLog = fetchedLogs.entries.first();
const unbanner = banRemoveLog ? banRemoveLog.executor : null;
const unbannerUsername = unbanner ? `\`\`\`${unbanner.username} (${unbanner.id})\`\`\`` : `\`\`\`UNKNOWN\`\`\``;
let banRemoveEmbed = new EmbedBuilder()
  .setTitle('**Member has been unbanned**')
  .addFields(
    { name: 'Member unbanned:', value: `\`\`\`${user.tag} (${user.id})\`\`\`` },
    { name: 'Unbanned by:', value: unbannerUsername }
  )
  .setTimestamp();
banRemoveLog2.send({ embeds: [banRemoveEmbed] });
}
});
// نهاية لوغ ازالة بان

//-

// بداية لوغ الطرد
client27.on('guildMemberRemove', async (member) => {
const guild = member.guild;
if (logsDB.has(`log_kickadd_${guild.id}`)) {
const kickLogChannelId = logsDB.get(`log_kickadd_${guild.id}`);
const kickLogChannel = guild.channels.cache.get(kickLogChannelId);
const fetchedLogs = await guild.fetchAuditLogs({
  limit: 1,
  type: AuditLogEvent.MemberKick,
});
const kickLog = fetchedLogs.entries.first();
const kicker = kickLog ? kickLog.executor : null;
const kickerUsername = kicker ? `\`\`\`${kicker.username} (${kicker.id})\`\`\`` : 'Unknown';
const kickEmbed = new EmbedBuilder()
  .setTitle('**Member has been kicked**')
  .addFields(
    { name: 'Member kicked:', value: `\`\`\`${member.user.tag} (${member.user.id})\`\`\`` },
    { name: 'Kicked by:', value: kickerUsername },
  )
  .setTimestamp();
kickLogChannel.send({ embeds: [kickEmbed] });
}
});
let invites = {}; 
const getInviteCounts = async (guild) => {
    return new Map(guild.invites.cache.map(invite => [invite.code, invite.uses]));
};
// نهاية لوغ الطرد

//-

// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM

//-

// -- Welcome -- \\
client27.on('inviteCreate', async invite => {
    if (!invites[invite.guild.id]) {
        invites[invite.guild.id] = new Map();
    }
    invites[invite.guild.id].set(invite.code, invite.uses);
});
client27.on('inviteDelete', async invite => {
    if (invites[invite.guild.id]) {
        invites[invite.guild.id].delete(invite.code);
    }
});
client27.on('guildMemberAdd', async member => {
    try {
        const welcomeChannelId = await systemDB.get(`welcome_channel_${member.guild.id}`);
        const welcomeRoleId = await systemDB.get(`welcome_role_${member.guild.id}`);
        const welcomeImage = await systemDB.get(`welcome_image_${member.guild.id}`);
        if (welcomeRoleId) {
            const role = member.guild.roles.cache.get(welcomeRoleId);
            if (role) {
                await member.roles.add(role);
            }
        }
        const newInvites = await member.guild.invites.fetch();
        const oldInvites = invites[member.guild.id] || new Map();
        const usedInvite = newInvites.find(inv => {
            const prevUses = oldInvites.get(inv.code) || 0;
            return inv.uses > prevUses;
        });
        let inviterMention = 'Unknown';
        if (usedInvite && usedInvite.inviter) {
            inviterMention = `<@${usedInvite.inviter.id}>`;
        }
        const fullUser = await client27.users.fetch(member.user.id, { force: true });
        const welcomeEmbed = new EmbedBuilder()
            .setAuthor({ name: member.guild.name, iconURL: member.guild.iconURL({ dynamic: true }) })
            .setFooter({ text: member.guild.name, iconURL: member.guild.iconURL({ dynamic: true }) })
            .setColor('#FF0000')
            .setTitle('Welcome to the Server!')
            .setDescription(`Hello ${member}, welcome to **${member.guild.name}**! Enjoy your stay.`)
            .addFields(
                { name: 'Username', value: member.user.tag, inline: true },
                { name: 'Invited By', value: inviterMention, inline: true },
                { name: 'Invite Used', value: usedInvite ? `||${usedInvite.code}||` : 'Direct Join', inline: true },
                { name: 'You\'re the Member', value: `${member.guild.memberCount}`, inline: true }
            )
            .setThumbnail(member.user.displayAvatarURL())
            .setTimestamp();
        if (welcomeImage) {
            welcomeEmbed.setImage(welcomeImage);
        }
        const welcomeChannel = member.guild.channels.cache.get(welcomeChannelId);
        if (welcomeChannel) {
            await welcomeChannel.send({ embeds: [welcomeEmbed] });
        }
        invites[member.guild.id] = new Map(newInvites.map(invite => [invite.code, invite.uses]));
    } catch (error) {
        console.error('Error handling guildMemberAdd event:', error);
    }
});
// -- Welcome -- \\

//-

// -- Nadeko -- \\
client27.on("guildMemberAdd" , async(member) => {
  const theeGuild = member.guild
  let rooms = nadekoDB.get(`rooms_${theeGuild.id}`)
  const message = nadekoDB.get(`message_${theeGuild.id}`)
  if(!rooms) return;
  if(rooms.length <= 0) return;
  if(!message) return;
  await rooms.forEach(async(room) => {
    const theRoom = await theeGuild.channels.cache.find(ch => ch.id == room)
    if(!theRoom) return;
    await theRoom.send({content:`**${message} - ${member}**`}).then(async(msg) => {
      setTimeout(() => {
        msg.delete();
      }, 3000);
    })
  })
})
// -- Nadeko -- \\

//-

// -- Reply -- \\
  client27.on("messageCreate" ,  async(message) => {
    if (!message.guild) return;
    if(message.author.bot) return;
    const autoReplys = one4allDB.get(`replys_${message.guild.id}`);
    if(!autoReplys) return;
    const data = autoReplys.find((r) => r.word == message.content);
    if(!data) return;
    message.reply(`${data.reply}`)
  })
// -- Reply -- \\

//-

// -- Help -- \\
client27.on("interactionCreate" , async(interaction) => {
    if(interaction.customId === "help_tax"){
      const embed = new EmbedBuilder()
          .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
          .setTitle('Bot Commands List')
          .addFields(
            {name : `\`/set-tax-room\`` , value : `To set the auto-tax channel`},
            {name : `\`/set-tax-line\`` , value : `To set the line`},
            {name : `\`/tax-mode\`` , value : `To set the tax mode`},
            {name : `\`/tax\` | \`${prefix}tax\`` , value : `To calculate ProBot tax for any amount`}
          )
          .setTimestamp()
          .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
          .setColor('FF0000');
          const btns1 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
            new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        )
        const btns2 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        )
        const btns3 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        )
        await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_autoline"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List')
      .addFields(
        {name : `\`/set-autoline-line\`` , value : `To set the line`},
        {name : `\`/add-autoline-channel\`` , value : `To add an auto-line channel`},
        {name : `\`/remove-autoline-channel\`` , value : `To remove an auto-line channel`},
        {name : `\`/line-mode\`` , value : `To set the line sending method`},
        {name : `\`line\`` , value : `To manually send a line`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_suggestion"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List')
      .addFields(
        {name : `\`/set-suggestions-line\`` , value : `To set the suggestions line`},
        {name : `\`/set-suggestions-room\`` , value : `To set the suggestions channel`},
        {name : `\`/suggestions-mode\`` , value : `To set the suggestions mode`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_feedback"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List')
      .addFields(
        {name : `\`/set-feedback-line\`` , value : `To set the feedback line`},
        {name : `\`/set-feedback-room\`` , value : `To set the feedback channel`},
        {name : `\`/feedback-mode\`` , value : `Embed or Reaction only mode`},
        {name : `\`/setup-rating\`` , value : `To setup the staff rating system`},
        {name : `\`${prefix}rate\`` , value : `Request a rating`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_system"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List')
      .addFields(
        {name : `\`/avatar\`` , value : `To view your avatar or someone else's`},
        {name : `\`/server\` | \`${prefix}server\`` , value : `To view server information`},
        {name : `\`/user\`` , value : `To view user information`},
        {name : `\`/banner\`` , value : `To view your banner or someone else's`},
        {name : `\`/setup-welcome\`` , value : `To setup the welcome system`},
        {name : `\`/add-info-button\`` , value : `To add an info button`},
        {name : `\`/ban\`` , value : `To ban or unban a user`},
        {name : `\`/clear\` | \`${prefix}clear\`` , value : `To clear a number of messages`},
        {name : `\`/come\` | \`${prefix}come\`` , value : `To summon a user`},
        {name : `\`/embed\`` , value : `To speak in an embed`},
        {name : `\`/hide\` | \`${prefix}hide\`` , value : `To hide a channel`},
        {name : `\`/kick\`` , value : `To kick a user`},
        {name : `\`/lock\` | \`${prefix}lock\`` , value : `To lock a channel`},
        {name : `\`/nickname\`` , value : `To set or remove a nickname`},
        {name : `\`/mute\`` , value : `To mute or unmute a user`},
        {name : `\`/role\`` , value : `To give or remove a role`},
        {name : `\`/roles\`` , value : `To list server roles`},
        {name : `\`/say\` | \`${prefix}say\`` , value : `To say something`},
        {name : `\`/send\`` , value : `To send a DM to someone`},
        {name : `\`/timeout\`` , value : `To timeout or untimeout a user`},
        {name : `\`/unhide\` | \`${prefix}unhide\`` , value : `To unhide a channel`},
        {name : `\`/unlock\` | \`${prefix}unlock\`` , value : `To unlock a channel`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_ticket"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List')
      .addFields(
        {name : `\`/setup-ticket\`` , value : `To create a new ticket panel`},
        {name : `\`/add-ticket-button\`` , value : `To add a button to the ticket`},
        {name : `\`/to-select\`` , value : `To convert ticket to select menu`},
        {name : `\`/set-ticket-log\`` , value : `To set log channels`},
        {name : `\`/add-user\`` , value : `To add a user to the ticket`},
        {name : `\`/remove-user\`` , value : `To remove a user from the ticket`},
        {name : `\`/rename\`` , value : `To rename the ticket`},
        {name : `\`/close\` | \`${prefix}close\`` , value : `To close the ticket`},
        {name : `\`/delete\` | \`${prefix}delete\`` , value : `To delete the ticket`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_giveaway"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List')
      .addFields(
        {name : `\`/gstart\`` , value : `To start a giveaway`},
        {name : `\`/gend\`` , value : `To end a giveaway`},
        {name : `\`/greroll\`` , value : `To reroll giveaway winners`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_protection"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List')
      .addFields(
        {name : `\`/anti-ban\`` , value : `To setup anti-ban protection`},
        {name : `\`/anti-bots\`` , value : `To setup anti-bot protection`},
        {name : `\`/anti-delete-roles\`` , value : `To setup anti-role-delete protection`},
        {name : `\`/anti-delete-rooms\`` , value : `To setup anti-channel-delete protection`},
        {name : `\`/protection-status\`` , value : `To check protection status`},
        {name : `\`/set-protect-logs\`` , value : `To set the protection log channel`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_logs"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List') 
      .addFields(
        {name : `\`/logs-info\`` , value : `To view logs system info`},
        {name : `\`/setup-logs\`` , value : `To setup the logs system`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_apply"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List')
      .addFields(
        {name : `\`/setup-apply\`` , value : `To setup the application system`},
        {name : `\`/new-apply\`` , value : `To create a new application`},
        {name : `\`/dm-mode\`` , value : `To toggle DM notifications (Accept/Reject)`},
        {name : `\`/close-apply\`` , value : `To close the current application`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_broadcast"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List') 
      .addFields(
        {name : `\`/send-broadcast-panel\`` , value : `To send the broadcast control panel`},
        {name : `\`${prefix}obc\`` , value : `To broadcast to online members`},
        {name : `\`${prefix}bc\`` , value : `To broadcast to everyone`},
        {name : `\`/remove-token\`` , value : `To remove a specific broadcast token`},
        {name : `\`/remove-all-tokens\`` , value : `To remove all broadcast tokens`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_nadeko"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List') 
      .addFields(
        {name : `\`/set-message\`` , value : `To set the welcome message`},
        {name : `\`/add-nadeko-room\`` , value : `To add a Nadeko channel`},
        {name : `\`/remove-nadeko-room\`` , value : `To remove a Nadeko channel`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else 
    if(interaction.customId === "help_autorole"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List') 
      .addFields(
        {name : `\`/new-panel\`` , value : `To create a new role panel`},
        {name : `\`/add-button\`` , value : `To add a new role button`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }else
    if(interaction.customId === "help_autoreply"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('Bot Commands List')
      .addFields(
        {name : `\`/autoreply-add\`` , value : `To add an auto-reply`},
        {name : `\`/autoreply-remove\`` , value : `To remove an auto-reply`},
        {name : `\`/autoreply-list\`` , value : `To list all auto-replies`},
      )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('FF0000');
      const btns1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    const btns3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>').setDisabled(true),
        new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
    )
    await interaction.update({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    }
  })
// -- Help -- \\

//-

// -- Bot Sound 24/7 -- \\
const { joinVoiceChannel } = require('@discordjs/voice');
client27.once('ready', () => {
    const voiceChannelId = '';
    const channel = client27.channels.cache.get(voiceChannelId);
    if (channel) {
        try {
            joinVoiceChannel({
                channelId: channel.id,
                guildId: channel.guild.id,
                adapterCreator: channel.guild.voiceAdapterCreator,
                selfDeaf: true, 
                selfMute: false
            });
            console.log(`✅ 24/7 Active: ${channel.name}`);
        } catch (error) {
            console.error("❌ Problem accessing the room.", error);
        }
    } else {
        console.log("❌ The ROM isn't there, check the ID.");
    }
});
// -- Bot Sound 24/7 -- \\

//-

// -- Login -- \\
console.log("Token from config is: " + (token ? "Found ✅" : "Missing ❌"));
console.log("Attempting to login...");
client27.login(token);
// -- Login -- \\

//-

// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM