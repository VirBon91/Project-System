module.exports = {
  token: "",
  clientId: "",
  prefix: "-",
  owner: "",
};