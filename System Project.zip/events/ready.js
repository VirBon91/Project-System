// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { Events, ActivityType } = require("discord.js");
module.exports = {
    name: Events.ClientReady, 
    once: true,
    execute(client) {
        client.user.setPresence({
            activities: [{
                name: "Dev by VirBon 91",
                type: ActivityType.Watching,
            }],
            status: 'idle',
        });
        console.log(`
██╗░░░██╗██╗██████╗░██████╗░░█████╗░███╗░░██╗
██║░░░██║██║██╔══██╗██╔══██╗██╔══██╗████╗░██║
██║░░░██║██║██████╔╝██████╔╝██║░░██║██╔██╗██║
╚██╗░██╔╝██║██╔══██╗██╔══██╗██║░░██║██║╚████║
░╚████╔╝░██║██║░░██║██████╔╝╚█████╔╝██║░╚███║
░░╚═══╝░░╚═╝╚═╝░░╚═╝╚═════╝░░╚════╝░╚═╝░░╚══╝

  [root@VirBon] ~ Initiate Multi-System Bot
        `);
    },
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM