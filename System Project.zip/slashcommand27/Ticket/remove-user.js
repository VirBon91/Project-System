// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/ticketDB");

module.exports = {
    adminsOnly: false,
    data: new SlashCommandBuilder()
        .setName('remove-user')
        .setDescription('Remove a user from the current ticket channel')
        .addUserOption(option => 
            option
                .setName('user')
                .setDescription('Select the user to remove')
                .setRequired(true)
        ),
    async execute(interaction) {
        const supportRoleID = db.get(`TICKET-PANEL_${interaction.channel.id}`)?.Support;

        if (!interaction.member.roles.cache.has(supportRoleID)) {
            return interaction.reply({ 
                content: `**You do not have permission to remove users from this ticket.**`, 
                flags: MessageFlags.Ephemeral
            });
        }

        const member = interaction.options.getMember('user');

        if (!db.has(`TICKET-PANEL_${interaction.channel.id}`)) {
            return interaction.reply({ 
                content: `**This channel isn't a ticket**`, 
                flags: MessageFlags.Ephemeral
            });
        }

        await interaction.channel.permissionOverwrites.edit(member.user.id, {
            ViewChannel: false,
            SendMessages: false
        });

        return interaction.reply({ content: `**${member} has been removed from the ticket ${interaction.channel}.**` });
    }
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM