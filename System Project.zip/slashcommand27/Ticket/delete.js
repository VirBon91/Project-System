// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const db = new Database('/Json-db/Bots/ticketDB');

module.exports = {
    adminsOnly: false,
    data: new SlashCommandBuilder()
        .setName('delete')
        .setDescription('Delete the current ticket channel'),
    async execute(interaction) {
        const Support = db.get(`TICKET-PANEL_${interaction.channel.id}`)?.Support;
        
        if (!interaction.member.roles.cache.has(Support)) {
            return interaction.reply({ 
                content: '**Only Support**', 
                flags: MessageFlags.Ephemeral 
            });
        } 
        
        if (!db.has(`TICKET-PANEL_${interaction.channel.id}`)) {
            return interaction.reply({ 
                content: '**This channel isn\'t a ticket**', 
                flags: MessageFlags.Ephemeral 
            });
        }
        
        const embed = new EmbedBuilder()
            .setColor('FF0000')
            .setDescription(`**#${interaction.channel.name} The channel will be deleted in 5 seconds...**`);
            
        await interaction.reply({ embeds: [embed] });
        
        setTimeout(() => {
            interaction.channel.delete().catch(err => console.log("Channel already deleted"));
        }, 4500);
        
        const Logs = db.get(`LogsRoom_${interaction.guild.id}`);
        const Log = interaction.guild.channels.cache.get(Logs);
        const Ticket = db.get(`TICKET-PANEL_${interaction.channel.id}`);
        
        if (Log && Ticket) {
            const logEmbed = new EmbedBuilder()
                .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
                .setTitle('Delete Ticket')
                .addFields(
                    { name: 'Name Ticket', value: `${interaction.channel.name}`, inline: true },
                    { name: 'Owner Ticket', value: `<@${Ticket.author}>`, inline: true },
                    { name: 'Deleted By', value: `${interaction.user}`, inline: true },
                )
                .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();
            Log.send({ embeds: [logEmbed] }).catch(console.error);
        }
        db.delete(`TICKET-PANEL_${interaction.channel.id}`);
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM