// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/ticketDB");

module.exports = {
    adminsOnly: false,
    data: new SlashCommandBuilder()
        .setName('close')
        .setDescription('Close the current ticket channel'),
    async execute(interaction) {
        const ticket = db.get(`TICKET-PANEL_${interaction.channel.id}`);
        if (!ticket) {
            return interaction.reply({ 
                content: "**Error: No data exists for this ticket in the database (it may have been deleted manually).**", 
                flags: MessageFlags.Ephemeral 
            });
        }
        if (!ticket.author) {
            return interaction.reply({ 
                content: "**Error: The ticket holder's ID could not be found.**", 
                flags: MessageFlags.Ephemeral 
            });
        }
        try {
            await interaction.channel.permissionOverwrites.edit(ticket.author, { ViewChannel: false });
        } catch (error) {
            console.log(`Could not edit permissions for user ${ticket.author}. They might have left the server.`);
        }
        
        const embed2 = new EmbedBuilder()
            .setDescription(`**Ticket closed by ${interaction.user}**`)
            .setColor("FF0000");
            
        const embed = new EmbedBuilder()
            .setDescription("```Support team Panel.```")
            .setColor("FF0000");
            
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId('delete').setLabel('Delete').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('Open').setLabel('Open').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('Tran').setLabel('Transcript').setStyle(ButtonStyle.Secondary)
            );
            
        await interaction.reply({ embeds: [embed2, embed], components: [row] });
        
        const logsRoomId = db.get(`LogsRoom_${interaction.guild.id}`);
        const logChannel = interaction.guild.channels.cache.get(logsRoomId);
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
                .setTitle('Close Ticket')
                .setFields(
                    { name: `Name Ticket`, value: `${interaction.channel.name}`, inline: true },
                    { name: `Owner Ticket`, value: `<@${ticket.author}>`, inline: true },
                    { name: `Closed By`, value: `${interaction.user}`, inline: true },
                )
                .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();
            logChannel.send({ embeds: [logEmbed] }).catch(err => console.log("Log channel error:", err));
        }
    }
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM