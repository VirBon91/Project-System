// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/ticketDB");

module.exports = {
    adminsOnly: false,
    data: new SlashCommandBuilder()
        .setName('rename')
        .setDescription('Rename the current ticket channel')
        .addStringOption(option => 
            option
                .setName('name')
                .setDescription('Enter the new channel name')
                .setRequired(true)
        ),
    async execute(interaction) {
        const supportRoleID = db.get(`TICKET-PANEL_${interaction.channel.id}`)?.Support;

        if (!interaction.member.roles.cache.has(supportRoleID)) {
            return interaction.reply({ 
                content: `**You do not have permission to rename this ticket.**`, 
                flags: MessageFlags.Ephemeral
            });
        }

        const newName = interaction.options.getString('name');
        const ticketData = db.get(`TICKET-PANEL_${interaction.channel.id}`);

        if (!ticketData) {
            return interaction.reply({ 
                content: `**This channel isn't a ticket**`, 
                flags: MessageFlags.Ephemeral
            });
        }

        if (!newName) {
            return interaction.reply({ 
                content: `**No new name provided for the ticket channel.**`, 
                flags: MessageFlags.Ephemeral 
            });
        }

        await interaction.channel.setName(newName);
        
        return interaction.reply({ 
            content: `**Ticket Renamed**`, 
            flags: MessageFlags.Ephemeral
        });
    }
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM