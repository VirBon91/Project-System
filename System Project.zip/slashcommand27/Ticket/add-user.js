// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/ticketDB");

module.exports = {
    adminsOnly: false,
    data: new SlashCommandBuilder()
        .setName('add-user')
        .setDescription('Add a user to the current ticket channel')
        .addUserOption(option => 
            option
                .setName('user')
                .setDescription('Select the user to add')
                .setRequired(true)
        ),
    async execute(interaction) {
        const member = interaction.options.getMember('user');
        const supportRoleID = db.get(`TICKET-PANEL_${interaction.channel.id}`)?.Support;

        if (!interaction.member.roles.cache.has(supportRoleID)) {
            return interaction.reply({ 
                content: '**You do not have permission to add users to this ticket.**', 
                flags: MessageFlags.Ephemeral
            });
        }

        if (!db.has(`TICKET-PANEL_${interaction.channel.id}`)) {
            return interaction.reply({ 
                content: '**This channel isn\'t a ticket**', 
                flags: MessageFlags.Ephemeral
            });
        }

        await interaction.channel.permissionOverwrites.edit(member.user.id, {
            ViewChannel: true,
            SendMessages: true
        });

        return interaction.reply({ 
            content: `**${member} has been added to the ticket ${interaction.channel}.**` 
        });
    }
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM