// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/nadekoDB.json");
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('add-nadeko-room')
        .setDescription('اضافة روم يتم تفعيل الخاصية فيها')
        .addChannelOption(Option => Option
            .setName(`room`)
            .setDescription(`الروم`)
            .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        const room = interaction.options.getChannel(`room`);
        let rooms = db.get(`rooms_${interaction.guild.id}`) || [];
        if (rooms.includes(room.id)) {
            return interaction.editReply({ content: `**This room is already added.**` });
        }
        await db.push(`rooms_${interaction.guild.id}`, room.id);
        return interaction.editReply({ content: `**The Room has been successfully added.**` });
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM