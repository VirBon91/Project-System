// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/nadekoDB.json")
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('remove-nadeko-room')
        .setDescription('ازالة روم مفعل الخاصية فيها')
        .addChannelOption(Option => Option
            .setName(`room`)
            .setDescription(`الروم`)
            .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        const room = interaction.options.getChannel(`room`)
        let rooms = db.get(`rooms_${interaction.guild.id}`) || [];
        if (!rooms.includes(room.id)) {
            return interaction.editReply({ content: `**This Room has not been added before, so it cannot be deleted.**` })
        }
        const filtered = rooms.filter(ro => ro !== room.id)
        await db.set(`rooms_${interaction.guild.id}`, filtered)
        return interaction.editReply({ content: `**The Room was successfully removed.**` })
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM