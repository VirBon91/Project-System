// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/nadekoDB.json");
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('set-message')
        .setDescription('تحديد الرسالة عند الدخول')
        .addStringOption(Option => Option
            .setName(`message`)
            .setDescription(`الرسالة`)
            .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        const message = interaction.options.getString(`message`);
        await db.set(`message_${interaction.guild.id}`, message);
        
        return interaction.editReply({ content: `**The message was successfully identified.**` });
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM