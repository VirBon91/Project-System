// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, ChatInputCommandInteraction, Client, EmbedBuilder, PermissionsBitField } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/logsDB.json");
module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
        .setName('logs-info')
        .setDescription('معلومات نظام اللوج في السيرفر'),
    async execute(interaction) {
        await interaction.deferReply();
        let messagedelete = await db.get(`log_messagedelete_${interaction.guild.id}`);
        let messageupdate = await db.get(`log_messageupdate_${interaction.guild.id}`);
        let rolecreate = await db.get(`log_rolecreate_${interaction.guild.id}`);
        let roledelete = await db.get(`log_roledelete_${interaction.guild.id}`);
        let rolegive = await db.get(`log_rolegive_${interaction.guild.id}`);
        let roleremove = await db.get(`log_roleremove_${interaction.guild.id}`);
        let channelcreate = await db.get(`log_channelcreate_${interaction.guild.id}`);
        let channeldelete = await db.get(`log_channeldelete_${interaction.guild.id}`);
        let botadd = await db.get(`log_botadd_${interaction.guild.id}`);
        let banadd = await db.get(`log_banadd_${interaction.guild.id}`);
        let bandelete = await db.get(`log_bandelete_${interaction.guild.id}`);
        let kickadd = await db.get(`log_kickadd_${interaction.guild.id}`);
        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('**Log system information**')
            .addFields(
                { name: `Delete a message`, value: `${messagedelete ? `<#${messagedelete}>` : '```Not specified```'}` , inline : true},
                { name: `Update message`, value: `${messageupdate ? `<#${messageupdate}>` : '```Not specified```'}` , inline : true},
                { name: `\n`, value: `\n`, inline: true },
                { name: `Create a role`, value: `${rolecreate ? `<#${rolecreate}>` : '```Not specified```'}` , inline : true},
                { name: `Delete role`, value: `${roledelete ? `<#${roledelete}>` : '```Not specified```'}` , inline : true},
                { name: `Give role`, value: `${rolegive ? `<#${rolegive}>` : '```Not specified```'}` , inline : true},
                { name: `Remove role`, value: `${roleremove ? `<#${roleremove}>` : '```Not specified```'}` , inline : true},
                { name: `\n`, value: `\n`, inline: true },
                { name: `\n`, value: `\n`, inline: true },
                { name: `Create a room`, value: `${channelcreate ? `<#${channelcreate}>` : '```Not specified```'}` , inline : true},
                { name: `Delete room`, value: `${channeldelete ? `<#${channeldelete}>` : '```Not specified```'}` , inline : true},
                { name: `\n`, value: `\n`, inline: true },
                { name: `Bot add`, value: `${botadd ? `<#${botadd}>` : '```Not specified```'}` , inline : true},
                { name: `\n`, value: `\n`, inline: true },
                { name: `\n`, value: `\n`, inline: true },
                { name: `Add ban`, value: `${banadd ? `<#${banadd}>` : '```Not specified```'}` , inline : true},
                { name: `Delete ban`, value: `${bandelete ? `<#${bandelete}>` : '```Not specified```'}` , inline : true},
                { name: `Kick`, value: `${kickadd ? `<#${kickadd}>` : '```Not specified```'}` , inline : true}
            )
            .setColor('FF0000')
            .setTimestamp()
            .setFooter({text : `Requeted by : ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})});
        await interaction.editReply({ embeds: [embed] });
    }
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM