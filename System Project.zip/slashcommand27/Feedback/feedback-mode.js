// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require('st.db');
const feedbackDB = new Database("/Json-db/Bots/feedbackDB.json");

module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('feedback-mode')
        .setDescription('امبد أو رياكشن فقط')
        .addStringOption(option =>
            option.setName('mode')
                .setDescription('Choose between Embed and Reaction')
                .setRequired(true)
                .addChoices(
                    { name: 'Embed', value: 'embed' },
                    { name: 'Auto Reaction Only', value: 'reactions' },
                ))
        .addStringOption(option =>
            option.setName('emoji')
                .setDescription('Emoji (for auto-reaction only)')
                .setRequired(false)),
    async execute(interaction) {
        const mode = interaction.options.getString('mode');
        const emoji = interaction.options.getString('emoji') || '❤';
        
        await feedbackDB.set(`feedback_mode_${interaction.guild.id}`, mode);
        await feedbackDB.set(`feedback_emoji_${interaction.guild.id}`, emoji);
        
        await interaction.reply({ 
            content: `The opinions were set on **${mode}**`, 
            flags: [MessageFlags.Ephemeral] 
        });
    },
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM