// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { ChatInputCommandInteraction, Client, SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require("discord.js");
const { Database } = require("st.db");
const feedbackDB = new Database("/Json-db/Bots/feedbackDB.json");
const isImage = require('is-image-header');
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('set-feedback-line')
        .setDescription('تحديد الخط')
        .addStringOption(option => 
            option
                .setName('line')
                .setDescription('الخط')
                .setRequired(true)),
    async execute(interaction) {
        try {
            await interaction.deferReply();
            const line = interaction.options.getString('line');
            await feedbackDB.set(`line_${interaction.guild.id}`, line);
            let embed = new EmbedBuilder()
                .setDescription('**The line is selected**')
                .setColor('FF0000')
                .setImage(line)
                .setTimestamp()
                .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) });
            return interaction.editReply({ embeds: [embed] });
        } catch (error) {
            console.log("⛔ | error in set-line command", error);
        }
    }
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM