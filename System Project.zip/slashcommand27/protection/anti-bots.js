// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/protectDB.json")

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('anti-bots')
        .setDescription('تسطيب نظام الحماية من البوتات')
        .addStringOption(Option => Option
            .setName(`status`)
            .setDescription(`الحالة`)
            .setRequired(true)
            .addChoices(
                { name: `On`, value: `on` },
                { name: `Off`, value: `off` }
            ))
    ,
    async execute(interaction) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] })
        try {
            const status = interaction.options.getString(`status`)
            await db.set(`antibots_status_${interaction.guild.id}`, status)
            
            return interaction.editReply({ content: `**The status has been successfully set\n - Make sure to raise my role to the highest rank on the server.**` })
        } catch (error) {
            console.error(error);
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM