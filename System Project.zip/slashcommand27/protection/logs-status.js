// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/protectDB.json");

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('protection-status')
        .setDescription('للاستعلام عن حالة نظام الحماية'),
    async execute(interaction) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        try {
            const guildID = interaction.guild.id;
            
            const banStatus = db.get(`ban_status_${guildID}`) || "off";
            const banLimit = db.get(`ban_limit_${guildID}`);
            
            const botsStatus = db.get(`antibots_status_${guildID}`) || "off";
            const botsLimit = "Undefined";
            
            const deleteRolesStatus = db.get(`antideleteroles_status_${guildID}`) || "off";
            const deleteRolesLimit = db.get(`antideleteroles_limit_${guildID}`) || "Undefined";
            
            const deleteRoomsStatus = db.get(`antideleterooms_status_${guildID}`) || "off";
            const deleteRoomsLimit = db.get(`antideleterooms_limit_${guildID}`) || "Undefined";

            const embed = new EmbedBuilder()
                .setTitle('Status of the protection system')
                .setColor('FF0000')
                .addFields(
                    { name: `Protection from bots`, value: `the condition : ${botsStatus == "on" ? "🟢" : "🔴"} \n Allowed number : \`${botsLimit}\`` },
                    { name: `Ban protection`, value: `the condition : ${banStatus == "on" ? "🟢" : "🔴"} \n Allowed number : \`${banLimit >= 0 ? banLimit : "Undefined"}\`` },
                    { name: `Protection against room deletion`, value: `the condition : ${deleteRoomsStatus == "on" ? "🟢" : "🔴"} \n Allowed number : \`${deleteRoomsLimit}\`` },
                    { name: `Protection against role deletion`, value: `the condition : ${deleteRolesStatus == "on" ? "🟢" : "🔴"} \n Allowed number : \`${deleteRolesLimit}\`` }
                );

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM