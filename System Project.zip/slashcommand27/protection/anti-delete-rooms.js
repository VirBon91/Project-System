// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/protectDB.json")

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('anti-delete-rooms')
        .setDescription('تسطيب نظام الحماية من حذف الرومات')
        .addStringOption(Option => Option
            .setName(`status`)
            .setDescription(`الحالة`)
            .setRequired(true)
            .addChoices(
                { name: `On`, value: `on` },
                { name: `Off`, value: `off` }
            ))
        .addIntegerOption(Option => Option
            .setName(`limit`)
            .setDescription(`العدد المسموح في اليوم`)
            .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] })
        try {
            const status = interaction.options.getString(`status`)
            const limit = interaction.options.getInteger(`limit`)
            
            await db.set(`antideleterooms_status_${interaction.guild.id}`, status)
            await db.set(`antideleterooms_limit_${interaction.guild.id}`, limit)
            await db.set(`roomsdelete_users_${interaction.guild.id}`, [])
            
            return interaction.editReply({ content: `**The room deletion protection system has been successfully set up. \n - Make sure to raise my role to the highest role on the server.**` })
        } catch (error) {
            console.error(error);
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM