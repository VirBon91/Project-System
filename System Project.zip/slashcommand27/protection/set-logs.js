// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/protectDB.json")

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('set-protect-logs')
        .setDescription('لتحديد روم لوج الحماية')
        .addChannelOption(Option =>
            Option
                .setName('room')
                .setDescription('الروم')
                .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] })
        try {
            let room = interaction.options.getChannel(`room`)
            await db.set(`protectLog_room_${interaction.guild.id}`, room.id)
            return interaction.editReply({ content: `**The room has been identified ${room} Successfully**` })
        } catch (error) {
            console.error(error);
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM