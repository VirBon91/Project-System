// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, MessageComponentCollector, ButtonStyle, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const applyDB = new Database("/Json-db/Bots/applyDB.json");

module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName("dm-mode")
        .setDescription("ارسال رسالة لخاص المتقدم عند الرفض او القبول")
        .addStringOption((option) =>
            option
                .setName("type")
                .setDescription("تفعيل / تعطيل نظام الخاص")
                .addChoices(
                    { name: 'تفعيل', value: 'enable' },
                    { name: 'تعطيل', value: 'disable' },
                )
                .setRequired(true)
        ),
    async execute(interaction, client) {
        const sent = await interaction.deferReply({
            fetchReply: true,
            flags: [MessageFlags.Ephemeral]
        });

        let embed1 = new EmbedBuilder()
            .setFooter({
                text: interaction.user.username,
                iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
            })
            .setAuthor({
                name: interaction.guild.name,
                iconURL: interaction.guild.iconURL({ dynamic: true }),
            })
            .setTimestamp(Date.now())
            .setColor('FF0000');

        let type = interaction.options.getString(`type`);

        if (type === "enable") {
            applyDB.set(`dm_${interaction.guild.id}`, true)
            embed1.setTitle(`**The private system has been activated**`)
        } else if (type === "disable") {
            applyDB.set(`dm_${interaction.guild.id}`, false)
            embed1.setTitle(`**Your system has been disabled**`)
        }
        return interaction.editReply({ embeds: [embed1] });
    },
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM