// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags
} = require("discord.js");
const { Database } = require("st.db");
const applyDB = new Database("/Json-db/Bots/applyDB.json");

module.exports = {
  ownersOnly: false,
  adminsOnly: true,
  data: new SlashCommandBuilder()
    .setName("new-apply")
    .setDescription("انشاء تقديم جديد")
    .addRoleOption((Option) =>
      Option.setName(`role`)
        .setDescription(`الرتبة التي سوف يتم انشاء التقديم عليها`)
        .setRequired(true)
    )
    .addStringOption((Option) =>
      Option.setName(`ask1`).setDescription(`السوال الاول`).setRequired(true)
    )
    .addStringOption((Option) =>
      Option.setName(`ask2`).setDescription(`السوال الثاني`).setRequired(false)
    )
    .addStringOption((Option) =>
      Option.setName(`ask3`).setDescription(`السوال الثالث`).setRequired(false)
    )
    .addStringOption((Option) =>
      Option.setName(`ask4`).setDescription(`السوال الرابع`).setRequired(false)
    )
    .addStringOption((Option) =>
      Option.setName(`ask5`).setDescription(`السوال الخامس`).setRequired(false)
    )
    .addAttachmentOption((Option) =>
      Option.setName(`image`).setDescription(`الصورة في ايمبد التقديم`).setRequired(false)
    )
    .addStringOption((Option) =>
      Option.setName(`button`).setDescription(`لون الزر في رسالة التقديم`).addChoices(
        { name: `رمادي`, value: '2' },
        { name: `ازرق`, value: '1' },
        { name: `اخضر`, value: '3' },
        { name: `احمر`, value: '4' },
      ).setRequired(false)
    ),
  async execute(interaction, client) {
    const settings = await applyDB.get(
      `apply_settings_${interaction.guild.id}`
    );
    if (!settings) {
      return interaction.reply({
        content: `**Please setup the submission system first. \n /setup-apply**`,
        flags: [MessageFlags.Ephemeral],
      });
    }

    let role = interaction.options.getRole(`role`);
    let ask1 = interaction.options.getString(`ask1`);
    let ask2 = interaction.options.getString(`ask2`);
    let ask3 = interaction.options.getString(`ask3`);
    let ask4 = interaction.options.getString(`ask4`);
    let ask5 = interaction.options.getString(`ask5`);
    let image = interaction.options.getAttachment(`image`);
    let button = interaction.options.getString(`button`) || "1";

    await applyDB.set(`apply_${interaction.guild.id}`, {
      roleid: role.id,
      ask1: ask1,
      ask2: ask2,
      ask3: ask3,
      ask4: ask4,
      ask5: ask5,
    });

    const modal = new ModalBuilder()
      .setCustomId('message_modal')
      .setTitle('Application Message');

    const messageInput = new TextInputBuilder()
      .setCustomId('message_input')
      .setLabel('Application Message in the Embed')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    const firstActionRow = new ActionRowBuilder().addComponents(messageInput);
    modal.addComponents(firstActionRow);

    await interaction.showModal(modal);

    const filter = (i) => i.customId === 'message_modal' && i.user.id === interaction.user.id;

    interaction.awaitModalSubmit({ filter, time: 60000 })
      .then(async (modalSubmit) => {
        const message = modalSubmit.fields.getTextInputValue('message_input');

        let theapplyroom = await interaction.guild.channels.cache.find(
          (ch) => ch.id == settings.applyroom
        );

        const applybutton = new ButtonBuilder()
          .setCustomId(`apply_button`)
          .setLabel(`Apply`)
          .setStyle(parseInt(button))
          .setEmoji("<:about:1329437457212637277>");
        const row = new ActionRowBuilder().addComponents(applybutton);

        const embed = new EmbedBuilder()
          .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
          .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
          .setColor('#FF0000')
          .setDescription(`**${message}**`);
        if (image) {
          embed.setImage(image.url);
        }

        await theapplyroom.send({ embeds: [embed], components: [row] });
        await modalSubmit.reply({ 
            content: '**The application message has been successfully sent!**', 
            flags: [MessageFlags.Ephemeral] 
        });
      })
      .catch((err) => {
      });
  },
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM