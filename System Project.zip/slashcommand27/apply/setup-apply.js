// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, MessageComponentCollector, ButtonStyle, MessageFlags } = require("discord.js");
const { Database } = require("st.db")
const applyDB = new Database("/Json-db/Bots/applyDB.json")

module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('setup-apply')
        .setDescription('تسطيب نظام التقديم')
        .addChannelOption(Option => Option
            .setName(`applyroom`)
            .setDescription(`روم التقديم`)
            .setRequired(true))
        .addChannelOption(Option => Option
            .setName(`appliesroom`)
            .setDescription(`روم وصول التقديمات`)
            .setRequired(true))
        .addChannelOption(Option => Option
            .setName(`resultsroom`)
            .setDescription(`روم النتائج`)
            .setRequired(true))
        .addRoleOption(Option => Option
            .setName(`adminrole`)
            .setDescription(`رتبة الادارة`)
            .setRequired(true)),
    async execute(interaction, client) {
        const sent = await interaction.deferReply({ 
            fetchReply: true, 
            flags: [MessageFlags.Ephemeral] 
        });

        let embed1 = new EmbedBuilder()
            .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTimestamp(Date.now())
            .setColor('#FF0000')

        let applyroom = interaction.options.getChannel(`applyroom`)
        let appliesroom = interaction.options.getChannel(`appliesroom`)
        let resultsroom = interaction.options.getChannel(`resultsroom`)
        let adminrole = interaction.options.getRole(`adminrole`)

        await applyDB.set(`apply_settings_${interaction.guild.id}`, {
            applyroom: applyroom.id,
            appliesroom: appliesroom.id,
            resultsroom: resultsroom.id,
            adminrole: adminrole.id,
        })
        
        embed1.setTitle(`**The submission system was successfully identified.**`)
        return interaction.editReply({ embeds: [embed1] })
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM