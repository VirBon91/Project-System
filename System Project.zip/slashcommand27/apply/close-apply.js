// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, MessageComponentCollector, ButtonStyle, MessageFlags } = require("discord.js");
const { Database } = require("st.db")
const applyDB = new Database("/Json-db/Bots/applyDB.json")
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('close-apply')
        .setDescription('انهاء التقديم المفتوح'),
    async execute(interaction, client) {
        const sent = await interaction.deferReply({ 
            fetchReply: true,
            flags: [MessageFlags.Ephemeral] 
        });
        let embed1 = new EmbedBuilder()
            .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTimestamp(Date.now())
            .setColor('#FF0000')
        let apply = await applyDB.get(`apply_${interaction.guild.id}`)
        if (!apply) {
            embed1.setTitle(`**There are no open applications at the moment.**`)
            return interaction.editReply({ embeds: [embed1] })
        }
        await applyDB.delete(`apply_${interaction.guild.id}`)
        embed1.setTitle(`**Application completed successfully**`)
        return interaction.editReply({ embeds: [embed1] })
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM