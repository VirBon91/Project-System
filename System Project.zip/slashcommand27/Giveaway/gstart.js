// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const giveawayDB = new Database("/Json-db/Bots/giveawayDB.json");
const ms = require('ms');
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('gstart')
        .setDescription('بدأ جيف اواي')
        .addStringOption(Option =>
            Option
                .setName('duration')
                .setDescription('المدة (مثال: 10m, 1h, 1d)')
                .setRequired(true))
        .addIntegerOption(Option => Option
            .setName(`winners`)
            .setDescription(`عدد الفائزين`)
            .setRequired(true))
        .addStringOption(Option => Option
            .setName(`prize`)
            .setDescription(`الجائزة`)
            .setRequired(true)),
    async execute(interaction) {
        const duration = interaction.options.getString(`duration`);
        const winners = interaction.options.getInteger(`winners`);
        const prize = interaction.options.getString(`prize`);
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        if (!/[mdhs]/i.test(duration)) {
            return interaction.editReply({ content: `**Please specify the time correctly.**` });
        }
        const durationMs = ms(duration);
        const endTime = Date.now() + durationMs;
        const endTimestamp = Math.floor(endTime / 1000);
        const embed = new EmbedBuilder()
            .setTitle(`**${prize}**`)
            .setDescription(`Ends : <t:${endTimestamp}:R> (<t:${endTimestamp}:f>)\nHosted by : ${interaction.user}\nEntries : **0**\nWinners: **${winners}**`)
            .setColor(`#FF0000`)
            .setTimestamp(endTime);
        const button = new ButtonBuilder()
            .setEmoji(`🎉`)
            .setStyle(ButtonStyle.Secondary)
            .setCustomId(`join_giveaway`)
            .setDisabled(false);
        const row = new ActionRowBuilder().addComponents(button);
        const giveawayMsg = await interaction.channel.send({ embeds: [embed], components: [row] });
        let giveaways = giveawayDB.get(`giveaways_${interaction.guild.id}`) || [];
        giveaways.push({
            messageid: giveawayMsg.id,
            channelid: interaction.channel.id,
            entries: [],
            winners: winners,
            prize: prize,
            duration: durationMs / 1000,
            dir1: endTimestamp,
            dir2: endTime,
            host: interaction.user.id,
            ended: false
        });
        await giveawayDB.set(`giveaways_${interaction.guild.id}`, giveaways);
        return interaction.editReply({ content: `**The giveaway was successfully created**` });
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM