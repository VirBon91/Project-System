// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, ButtonStyle, PermissionsBitField, ButtonBuilder, ActionRowBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db")
const giveawayDB = new Database("/Json-db/Bots/giveawayDB.json")
const moment = require('moment');
const ms = require('ms')
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('gend')
        .setDescription('انهاء جيف اواي')
        .addStringOption(Option =>
            Option
                .setName('giveawayid')
                .setDescription('ايدي رسالة الجيف اواي')
                .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] })
        const giveawayid = interaction.options.getString(`giveawayid`)
        let giveaways = giveawayDB.get(`giveaways_${interaction.guild.id}`)
        if (!giveaways) {
            await giveawayDB.set(`giveaways_${interaction.guild.id}`, [])
            giveaways = []
        }
        try {
            await interaction.channel.messages.fetch(giveawayid)
        } catch (error) {
        }
        const giveawayFind = giveaways.find(gu => gu.messageid == giveawayid)
        if (!giveawayFind) {
            return interaction.editReply({ content: `**Giveaway was not found in these hands.**` })
        }
        let { ended } = giveawayFind;
        if (ended == true) {
            return interaction.editReply({ content: `**This giveaway has already ended.**` })
        }
        giveawayFind.duration = 0;
        giveawayFind.ended = true;
        await giveawayDB.set(`giveaways_${interaction.guild.id}`, giveaways)
        return interaction.editReply({ content: `**This giveaway has been successfully completed.**` })
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM