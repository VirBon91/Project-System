// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require("discord.js");
const { Database } = require("st.db");
const giveawayDB = new Database("/Json-db/Bots/giveawayDB.json");
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('greroll')
        .setDescription('اعادة فائزين جيف اواي')
        .addStringOption(Option =>
            Option
                .setName('giveawayid')
                .setDescription('ايدي رسالة الجيف اواي')
                .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        const giveawayid = interaction.options.getString(`giveawayid`);
        let giveaways = giveawayDB.get(`giveaways_${interaction.guild.id}`);
        if (!giveaways) return interaction.editReply({ content: `**Giveaway was not found.**` });
        const giveawayFind = giveaways.find(gu => gu.messageid == giveawayid);
        if (!giveawayFind) return interaction.editReply({ content: `**Giveaway was not found.**` });
        let { messageid, channelid, entries, winners, prize, ended } = giveawayFind;
        if (ended == false) return interaction.editReply({ content: `**This giveaway is not over yet**` });
        const theroom = interaction.guild.channels.cache.get(channelid);
        if (!theroom) return interaction.editReply({ content: `**Channel not found.**` });
        let themsg;
        try {
            themsg = await theroom.messages.fetch(messageid);
        } catch (error) {
            return interaction.editReply({ content: `**The giveaway message was not found (it might be deleted).**` });
        }
        if (entries.length > 0 && entries.length >= winners) {
            const theWinners = [];
            let entriesPool = [...entries]; 
            for (let i = 0; i < winners; i++) {
                let winnerIndex = Math.floor(Math.random() * entriesPool.length);
                let winnerId = entriesPool.splice(winnerIndex, 1)[0];
                theWinners.push(`<@${winnerId}>`);
            }
            themsg.reply({ content: `Congratulations ${theWinners.join(', ')}! You won the **${prize}**!` });
        } else {
            themsg.reply({ content: `**There are not enough subscribers.**` });
        }
        return interaction.editReply({ content: `**The winners of this giveaway have been successfully reinstated.**` });
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM