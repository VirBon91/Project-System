// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { 
    SlashCommandBuilder, 
    ButtonBuilder, 
    ActionRowBuilder, 
    ButtonStyle, 
    MessageFlags 
} = require('discord.js');
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('add-button')
        .setDescription('اضافة زر للرتبة أخرى')
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('الرتبة')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('label')
                .setDescription('اسم الزر')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('message-id')
                .setDescription('ايدي الرسالة')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('color')
                .setDescription('لون الزر')
                .setRequired(true)
                .addChoices(
                    { name: 'أزرق', value: 'Primary' },
                    { name: 'أحمر', value: 'Danger' },
                    { name: 'أخضر', value: 'Success' },
                    { name: 'رمادي', value: 'Secondary' },
                )),
    async execute(interaction) {
        const role = interaction.options.getRole('role');
        const label = interaction.options.getString('label');
        const messageId = interaction.options.getString('message-id');
        const color = interaction.options.getString('color');
        const guildId = interaction.guild.id;
        const button = new ButtonBuilder()
            .setCustomId(`getrole_${guildId}_${role.id}`)
            .setLabel(label)
            .setStyle(ButtonStyle[color]);
        try {
            const targetMessage = await interaction.channel.messages.fetch(messageId).catch(() => null);
            if (!targetMessage) {
                return await interaction.reply({ 
                    content: '**Please make sure the ID is correct and you are in the same channel.**', 
                    flags: [MessageFlags.Ephemeral] 
                });
            }
            if (targetMessage.author.id !== interaction.client.user.id) {
                return await interaction.reply({ 
                    content: '**I cannot edit a message that isn\'t mine.**', 
                    flags: [MessageFlags.Ephemeral] 
                });
            }
            const newRow = new ActionRowBuilder();
            if (targetMessage.components.length > 0) {
                const existingRow = targetMessage.components[0];
                if (existingRow.components.length >= 5) {
                    return await interaction.reply({ 
                        content: '**The button limit for this row (5 buttons) has been reached.**', 
                        flags: [MessageFlags.Ephemeral] 
                    });
                }
                existingRow.components.forEach(existingComponent => {
                    newRow.addComponents(ButtonBuilder.from(existingComponent));
                });
            }
            newRow.addComponents(button);
            await targetMessage.edit({ components: [newRow] });
            await interaction.reply({ 
                content: '**The button has been added successfully.**', 
                flags: [MessageFlags.Ephemeral] 
            });
        } catch (error) {
            console.error(error);
            await interaction.reply({ 
                content: '**An error occurred while adding the button.**', 
                flags: [MessageFlags.Ephemeral] 
            });
        }
    }
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM