// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder ,ButtonStyle, PermissionsBitField, ButtonBuilder, ActionRowBuilder } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/taxDB")
module.exports = {
    adminsOnly:true,
    data: new SlashCommandBuilder()
    .setName('set-tax-room')
    .setDescription('تحديد روم الضريبة التلقائية')
    .addChannelOption(Option => 
        Option
        .setName('room')
        .setDescription('الروم')
        .setRequired(true)),
async execute(interaction) {
    let room = interaction.options.getChannel(`room`)
    await db.set(`tax_room_${interaction.guild.id}` , room.id)
    return interaction.reply({content:`**The room has been identified ${room} Successfully**`})
}
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM