// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, MessageFlags } = require('discord.js');
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('copy-emoji')
        .setDescription('لنسخ ايموجي')
        .addStringOption(option =>
            option.setName('emoji')
                .setDescription('الإيموجي')
                .setRequired(true)
        ),
    async execute(interaction) {
        const emojiInput = interaction.options.getString('emoji');
        const emojiURL = getEmojiURL(emojiInput);
        if (!emojiURL) {
            return interaction.reply({ 
                content: '**Error, please provide a valid emoji.**', 
                flags: [MessageFlags.Ephemeral] 
            });
        }
        const nameMatch = emojiInput.match(/:(\w+):/);
        const emojiName = nameMatch ? nameMatch[1] : 'copied_emoji';
        try {
            const emoji = await interaction.guild.emojis.create({ attachment: emojiURL, name: emojiName });
            return interaction.reply(`**${emoji} Emoji copied successfully.**`);
        } catch (error) {
            console.error(error);
            return interaction.reply({ 
                content: 'An error occurred while uploading the emoji.', 
                flags: [MessageFlags.Ephemeral] 
            });
        }
    }
};
function getEmojiURL(emojiInput) {
    const emojiRegex = /<:.+:(\d+)>|<a:.+:(\d+)>/;
    const match = emojiInput.match(emojiRegex);
    if (match) {
        const emojiId = match[1] || match[2];
        const isAnimated = emojiInput.startsWith('<a:');
        return `https://cdn.discordapp.com/emojis/${emojiId}.${isAnimated ? 'gif' : 'png'}`;
    }
    return null;
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM