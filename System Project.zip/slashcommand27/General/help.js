// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder  , ChatInputCommandInteraction , Client, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
module.exports = {
    ownersOnly:false,
    data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('قائمة اوامر البوت'),
async execute(interaction) {
    try {
        await interaction.deferReply();
        const embed = new EmbedBuilder()
            .setAuthor({ name: 'VirBon 91', iconURL: interaction.client.user.displayAvatarURL() }) 
            .setTitle('Control Panel & Commands') 
            .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true })) 
            .setDescription(`
> **Welcome! Please select the appropriate section from the menu below.**
> **An integrated system to serve you with the best standards.**

\`\`\`yml
Developed By : VirBon 91
\`\`\`
`) 
            .addFields(
                { name: '📊 System Statistics', value: `\`\`\`+80 Commands Available\`\`\``, inline: false }
            )
            .setTimestamp()
            .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setColor('FF0000');
        const btns1 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_tax').setLabel('Tax').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_autoline').setLabel('Auto Line').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_suggestion').setLabel('Suggestions').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_feedback').setLabel('Feedback').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_system').setLabel('System').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        )
        const btns2 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_ticket').setLabel('Ticket').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_giveaway').setLabel('Giveaway').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_protection').setLabel('Protection').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_logs').setLabel('Logs').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_apply').setLabel('Apply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        )
        const btns3 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_broadcast').setLabel('Broadcast').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_nadeko').setLabel('Nadeko').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_autoreply').setLabel('Auto Reply').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
            new ButtonBuilder().setCustomId('help_autorole').setLabel('Auto Role').setStyle(ButtonStyle.Secondary).setEmoji('<:dossier:1329437455098707968>'),
        )
        await interaction.editReply({embeds : [embed] , components : [btns1 , btns2 , btns3]});
    } catch (error) {
        console.log("🔴 | Error in help all in one bot" , error)
    }
}
    };
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM