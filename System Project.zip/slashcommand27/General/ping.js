// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('لتجربة سرعة البوت'),
    async execute(interaction) {
        const sent = await interaction.reply({ 
            content: '**Calculating...**', 
            fetchReply: true 
        });
        const latency = sent.createdTimestamp - interaction.createdTimestamp;
        let apiPing = interaction.client.ws.ping;
        let apiPingDisplay = apiPing === -1 ? "⏳ Loading..." : `${apiPing}ms`;
        let embed1 = new EmbedBuilder()
            .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTimestamp()
            .setColor(apiPing === -1 || apiPing > 200 ? '#FF0000' : apiPing < 100 ? '#00FF00' : '#FFFF00') 
            .setTitle(`🏓 **Pong!**`)
            .addFields(
                { name: '📥 **Bot Latency**', value: `\`${latency}ms\``, inline: true },
                { name: '📡 **Discord API**', value: `\`${apiPingDisplay}\``, inline: true }
            );
        return interaction.editReply({ content: ``, embeds: [embed1] });
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM