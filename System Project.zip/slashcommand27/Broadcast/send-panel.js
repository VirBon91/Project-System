const { SlashCommandBuilder, EmbedBuilder ,ButtonStyle, PermissionsBitField, ButtonBuilder, ActionRowBuilder } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/BroadcastDB")
module.exports = {
    adminsOnly:true,
    data: new SlashCommandBuilder()
    .setName('send-broadcast-panel')
    .setDescription('ارسال بانل التحكم في البرودكاست'),
async execute(interaction) {
    await interaction.deferReply({ephemeral:false})
    try {
        const broadcast_msg = db.get(`broadcast_msg_${interaction.guild.id}`) ?? "No message specified"
        const msgid = db.get(`msgid_${interaction.guild.id}`)
        if(msgid) {
            let chan = interaction.guild.channels.cache.forEach(async(channel) => {
                try {
                    msg = channel.messages.fetch(msgid).then(async(msgg) => {
                         msgg.delete()
                     }).catch(async() => {return;})
                } catch {
                    
                }
            })
        }
        const tokens = db.get(`tokens_${interaction.guild.id}`) ?? 0;
        const embed = new EmbedBuilder()
        .setTitle(`**Broadcast control**`)
        .addFields(
            {
                name:`**Number of bots currently registered**`,value:`**\`\`\`${tokens.length ?? 0} From bots\`\`\`**`,inline:false
            },
            {
                name:`**Current broadcast message**`,value:`**\`\`\`${broadcast_msg}\`\`\`**`,inline:false
            },
        )
        .setDescription(`**You can control the bot using the buttons.**`)
        .setColor('FF0000')
        .setFooter({text:interaction.user.username , iconURL:interaction.user.displayAvatarURL({dynamic:true})})
        .setAuthor({name:interaction.guild.name , iconURL:interaction.guild.iconURL({dynamic:true})})
        .setTimestamp(Date.now())
        const add_token = new ButtonBuilder()
        .setCustomId(`add_token_button`)
        .setLabel(`Add Broadcast Token`)
        .setStyle(ButtonStyle.Primary)
        .setDisabled(false)
        .setEmoji(`<:bot:1329437466251497493>`)
        const broadcast_message = new ButtonBuilder()
        .setCustomId(`broadcast_message_button`)
        .setLabel(`Setting the broadcast message`)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(false)
        .setEmoji(`<:chat:1329437493438844989>`)
        const start_broadcast = new ButtonBuilder()
        .setCustomId(`run_broadcast_button`)
        .setLabel(`Start The broadcast`)
        .setStyle(ButtonStyle.Success)
        .setDisabled(false)
        .setEmoji(`<:yes:1329437524048740442>`)
        const row = new ActionRowBuilder()
        .addComponents(add_token,broadcast_message,start_broadcast)
        let newmsg = await interaction.editReply({embeds:[embed] , components:[row]})
        await db.set(`msgid_${interaction.guild.id}` , newmsg.id)
        return;
    } catch {
    }
}
}