// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/BroadcastDB");
module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('remove-all-tokens')
        .setDescription('إزالة جميع بوتات البرودكاست'),
    async execute(interaction) {
        try {
            await db.delete(`tokens_${interaction.guild.id}`);
            return interaction.reply({ content: '**All tokens have been successfully removed from the server.**' });
        } catch (error) {
            return interaction.reply({ content: `**An error occurred**` });
        }
    }
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM