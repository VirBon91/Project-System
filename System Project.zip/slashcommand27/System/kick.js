// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, PermissionsBitField, MessageFlags } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('اعطاء طرد لشخص او ازالته')
        .addUserOption(Option => Option
            .setName(`member`)
            .setDescription(`الشخص`)
            .setRequired(true))
        .addStringOption(Option => Option
            .setName(`reason`)
            .setDescription(`السبب`)
            .setRequired(false))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.KickMembers),

    async execute(interaction) {
        const member = interaction.options.getMember(`member`);
        const reasonInput = interaction.options.getString(`reason`) || "No reason provided";
        const finalReason = `${reasonInput} , By : ${interaction.user.id}`;
        if (!member) {
            return interaction.reply({ 
                content: `**Member not found.**`, 
                flags: [MessageFlags.Ephemeral] 
            });
        }
        if (!member.kickable) {
            return interaction.reply({ 
                content: `**I cannot kick this member (Their role is higher than or equal to mine).**`, 
                flags: [MessageFlags.Ephemeral] 
            });
        }

        try {
            await member.kick(finalReason);
            return interaction.reply({ content: `**The member was successfully kicked**` });
        } catch (error) {
            console.error(error);
            return interaction.reply({ 
                content: `**An error occurred (Check my permissions).**`, 
                flags: [MessageFlags.Ephemeral] 
            });
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM