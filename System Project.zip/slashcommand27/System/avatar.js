// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('avatar')
        .setDescription('رؤية افاتارك او شخص اخر')
        .addUserOption(Option => Option
            .setName(`user`)
            .setDescription(`الشخص`)
            .setRequired(false)),
    async execute(interaction) {
        await interaction.deferReply(); 
        
        const user = interaction.options.getUser(`user`) || interaction.user;
        const avatarUrl = user.displayAvatarURL({ dynamic: true, size: 4096 });
        
        const button = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setStyle(ButtonStyle.Link)
                .setLabel("Download")
                .setURL(avatarUrl)
        );

        const embed = new EmbedBuilder()
            .setAuthor({ name: user.username, iconURL: avatarUrl })
            .setTitle(`Avatar link`)
            .setColor('#FF0000')
            .setURL(avatarUrl)
            .setImage(avatarUrl)
            .setFooter({ text: `Requested by ` + interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });
            
        return interaction.editReply({ embeds: [embed], components: [button] });
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM