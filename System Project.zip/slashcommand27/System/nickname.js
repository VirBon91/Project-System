// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('nickname')
        .setDescription('اعطاء اسم مستعار لشخص او ازالته')
        .addUserOption(Option => Option
            .setName(`user`)
            .setDescription(`الشخص`)
            .setRequired(true))
        .addStringOption(Option => Option
            .setName(`nickname`)
            .setDescription(`الاسم المستعار (اتركه فارغاً لإزالة اللقب)`)
            .setRequired(false))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageNicknames),

    async execute(interaction) {
        await interaction.deferReply();

        try {
            const member = interaction.options.getMember(`user`);
            const nickname = interaction.options.getString(`nickname`);

            if (!member) {
                return interaction.editReply({ content: `**I couldn't find the member.**` });
            }

            if (!member.manageable) {
                return interaction.editReply({ content: `**I cannot change this member's nickname (Role is higher or equal to mine).**` });
            }

            if (nickname) {
                await member.setNickname(nickname);
                return interaction.editReply({ content: `**Nickname has been changed to __${nickname}__**` });
            } else {
                await member.setNickname(null);
                return interaction.editReply({ content: `**Nickname has been reset for __${member.user.username}__**` });
            }

        } catch (error) {
            console.error(`🔴 | error in nickname command`, error);
            return interaction.editReply({ content: `**An error occurred (Check my permissions).**` });
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM