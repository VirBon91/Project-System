// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, PermissionsBitField, MessageFlags } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('roles')
        .setDescription('للاستعلام عن رتب السيرفر')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageRoles),
    async execute(interaction) {
        await interaction.deferReply();

        try {
            const allRoles = interaction.guild.roles.cache.sort((a, b) => b.position - a.position);

            let rolesString = "";
            let names = allRoles.map((role) => role.name);
            
            let longest = names.reduce((long, str) => Math.max(long, str.length), 0);

            allRoles.forEach((role) => {
                rolesString += `${role.name}${" ".repeat(longest - role.name.length)} : ${role.members.size} members\n`;
            });

            const chunkSizeLimit = 1990;
            for (let i = 0; i < rolesString.length; i += chunkSizeLimit) {
                const chunk = rolesString.substring(i, i + chunkSizeLimit);
                const messageContent = `\`\`\`js\n${chunk}\n\`\`\``;

                if (i === 0) {
                    await interaction.editReply(messageContent);
                } else {
                    await interaction.followUp(messageContent);
                }
            }

        } catch (error) {
            console.error(error);
            await interaction.followUp({ 
                content: `**An error occurred. Contact the developers.**`, 
                flags: [MessageFlags.Ephemeral] 
            });
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM