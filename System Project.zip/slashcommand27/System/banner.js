// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('banner')
        .setDescription('رؤية بانرك او شخص اخر')
        .addUserOption(Option => Option
            .setName(`user`)
            .setDescription(`الشخص`)
            .setRequired(false)),
    async execute(interaction) {
        await interaction.deferReply();
        try {
            const userOption = interaction.options.getUser(`user`) || interaction.user;
            const fetchedUser = await interaction.client.users.fetch(userOption.id, { force: true });
            const bannerUrl = fetchedUser.bannerURL({ size: 2048, extension: "png", forceStatic: false });
            if (bannerUrl) {
                let button = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setStyle(ButtonStyle.Link)
                        .setLabel("Download")
                        .setURL(bannerUrl)
                );
                let embed = new EmbedBuilder()
                    .setAuthor({ name: fetchedUser.username, iconURL: fetchedUser.displayAvatarURL({ dynamic: true, size: 1024 }) })
                    .setTitle(`Banner link`)
                    .setURL(bannerUrl)
                    .setImage(bannerUrl)
                    .setColor('#FF0000')
                    .setFooter({ text: `Requested by ` + interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });
                await interaction.editReply({ embeds: [embed], components: [button] });
            } else {
                const accentColor = fetchedUser.hexAccentColor;
                if (accentColor) {
                    const hexColor = accentColor.replace('#', '');
                    let url = `https://single-color-image.herokuapp.com/${hexColor}/512x200`;

                    let embed = new EmbedBuilder()
                        .setAuthor({ name: fetchedUser.username, iconURL: fetchedUser.displayAvatarURL({ dynamic: true, size: 1024 }) })
                        .setTitle(`Banner Color`)
                        .setURL(url)
                        .setImage(url)
                        .setColor(accentColor)
                        .setFooter({ text: `Requested by ` + interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });
                    await interaction.editReply({ embeds: [embed] });
                } else {
                    await interaction.editReply({ content: `**This member does not have a banner.**` });
                }
            }
        } catch (error) {
            console.log("🔴 | error in banner command", error);
            await interaction.editReply({ content: `**An error occurred. Contact the developers.**` });
        }
    }
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM