// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, MessageFlags } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('embed')
        .setDescription('قول كلام في ايمبد')
        .addStringOption((option) => option
            .setName('title')
            .setDescription(`العنوان`)
            .setRequired(true))
        .addAttachmentOption((option) => option
            .setName('image')
            .setDescription(`صورة`)
            .setRequired(false))
        .addChannelOption((option) => option
            .setName('channel')
            .setDescription(`منشن الروم`)
            .setRequired(false))
        .addStringOption((option) => option
            .setName('color')
            .setDescription(`اللون`)
            .addChoices(
                { name: `احمر`, value: 'Red' },
                { name: `ازرق`, value: 'Blue' },
                { name: `ازرق فاتح`, value: 'Aqua' },
                { name: `اخضر`, value: 'Green' },
                { name: `اصفر`, value: 'Yellow' },
                { name: `اسود`, value: 'Black' },
                { name: `ذهبي`, value: 'Gold' },
                { name: `ابيض`, value: 'White' },
                { name: `برتقالي`, value: 'Orange' },
                { name: `رمادي`, value: 'Grey' },
                { name: `بدون لون`, value: 'DarkButNotBlack' },
                { name: `عشوائي`, value: 'Random' },
            )
            .setRequired(false))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageMessages),
    async execute(interaction) {
        try {
            let title = interaction.options.getString('title');
            let imageOption = interaction.options.getAttachment('image');
            let color = interaction.options.getString('color') || "Random";
            let image = imageOption ? imageOption.proxyURL : null;
            let channel = interaction.options.getChannel('channel') || interaction.channel;

            await interaction.reply({ 
                content: "**Please write the message you wish to place in the embed.**", 
                flags: [MessageFlags.Ephemeral] 
            });

            const filter = (msg) => msg.author.id === interaction.user.id;
            const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 60000 });

            collector.on('collect', async (msg) => {
                let embed = new EmbedBuilder()
                    .setTitle(`${title}`)
                    .setDescription(msg.content)
                    .setColor(color);

                if (image) {
                    embed.setImage(`${image}`);
                }

                await msg.delete().catch(() => {});
                
                await channel.send({ embeds: [embed] });
                
                return interaction.followUp({ 
                    content: `**The embed was successfully sent.**`, 
                    flags: [MessageFlags.Ephemeral] 
                });
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    interaction.followUp({ 
                        content: "**No message was received and the transaction was cancelled.**", 
                        flags: [MessageFlags.Ephemeral] 
                    });
                }
            });
        } catch (error) {
            console.log(error);
            if (!interaction.replied) {
                interaction.reply({ 
                    content: `**An error occurred, please contact the developers.**`, 
                    flags: [MessageFlags.Ephemeral] 
                });
            }
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM