// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, PermissionsBitField, MessageFlags } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('role')
        .setDescription('اعطاء رتبة لشخص او ازالتها')
        .addUserOption(Option => Option
            .setName(`member`)
            .setDescription(`الشخص`)
            .setRequired(true))
        .addRoleOption(Option => Option
            .setName(`role`)
            .setDescription(`الرتبة`)
            .setRequired(true))
        .addStringOption(Option => Option
            .setName(`give_or_remove`)
            .setDescription(`الاعطاء ام السحب`)
            .setRequired(true)
            .addChoices(
                { name: `Give`, value: `Give` },
                { name: `Remove`, value: `Remove` }
            ))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageRoles),

    async execute(interaction) {
        const member = interaction.options.getMember(`member`);
        const role = interaction.options.getRole(`role`);
        const action = interaction.options.getString(`give_or_remove`);

        if (!member) {
            return interaction.reply({ content: `**Member not found.**`, flags: [MessageFlags.Ephemeral] });
        }

        if (!role.editable) {
            return interaction.reply({ 
                content: `**I cannot manage this role because it is higher than or equal to my highest role.**`, 
                flags: [MessageFlags.Ephemeral] 
            });
        }

        try {
            if (action === "Give") {

                if (member.roles.cache.has(role.id)) {
                    return interaction.reply({ 
                        content: `**The member already has this role.**`, 
                        flags: [MessageFlags.Ephemeral] 
                    });
                }
                
                await member.roles.add(role);
                return interaction.reply({ content: `**The role was successfully awarded to the person.**` });
            }

            if (action === "Remove") {
                if (!member.roles.cache.has(role.id)) {
                    return interaction.reply({ 
                        content: `**This person does not have that role to remove it.**`, 
                        flags: [MessageFlags.Ephemeral] 
                    });
                }

                await member.roles.remove(role);
                return interaction.reply({ content: `**The person's role was successfully removed.**` });
            }

        } catch (error) {
            console.error(error);
            return interaction.reply({ 
                content: `**Please check my permissions and try again.**`, 
                flags: [MessageFlags.Ephemeral] 
            });
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM