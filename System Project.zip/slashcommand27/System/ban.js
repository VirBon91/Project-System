// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, PermissionsBitField, MessageFlags } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('اعطاء بان لشخص او ازالته')
        .addUserOption(Option => Option
            .setName(`member`)
            .setDescription(`الشخص`)
            .setRequired(true))
        .addStringOption(Option => Option
            .setName(`reason`)
            .setDescription(`السبب`)
            .setRequired(false))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.BanMembers),
    async execute(interaction, client) {
        try {
            const user = interaction.options.getUser(`member`);
            const member = interaction.options.getMember(`member`);
            const reason = interaction.options.getString(`reason`) || 'No reason provided';
            const finalReason = `${reason} , By : ${interaction.user.id}`;

            if (member && !member.bannable) {
                return interaction.reply({ 
                    content: `**I cannot ban this user because their role is higher than mine or equal to mine.**`, 
                    flags: [MessageFlags.Ephemeral] 
                });
            }

            let isBanned = false;
            try {
                await interaction.guild.bans.fetch(user.id);
                isBanned = true;
            } catch {
                isBanned = false;
            }

            if (!isBanned) {
                await interaction.guild.members.ban(user.id, { reason: finalReason });
                return interaction.reply({ content: `**The ban was successfully administered to the person.**` });
            } else {
                await interaction.guild.members.unban(user.id, finalReason);
                return interaction.reply({ content: `**The ban was successfully removed from the person.**` });
            }

        } catch (error) {
            console.log(error);
            return interaction.reply({ 
                content: `**An error occurred or I don't have enough permissions.**`, 
                flags: [MessageFlags.Ephemeral] 
            });
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM