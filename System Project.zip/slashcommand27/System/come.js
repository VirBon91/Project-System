// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('come')
        .setDescription('استدعاء شخص للروم الحالي')
        .addUserOption(option => option
            .setName('user')
            .setDescription('الشخص المراد استدعائه')
            .setRequired(true)),
    async execute(interaction, client) {
        try {
            await interaction.deferReply(); 
            const targetUser = interaction.options.getUser('user');
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
                return interaction.editReply({
                    content: `**You do not have the authority to do that.**`
                });
            }
            const channelLink = `https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`;
            const dmEmbed = new EmbedBuilder()
                .setTitle('Notice')
                .setDescription(`**You have been summoned by staff.**`)
                .addFields(
                    { name: 'By Admin:', value: `${interaction.user}`, inline: true },
                    { name: 'Server:', value: `${interaction.guild.name}`, inline: true },
                    { name: 'Channel:', value: `${interaction.channel}`, inline: true }
                )
                .setColor('#FF0000')
                .setFooter({ text: 'Please join as soon as possible' })
                .setTimestamp();
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Join Channel')
                        .setStyle(ButtonStyle.Link)
                        .setURL(channelLink)
                );
            await targetUser.send({ 
                content: `${targetUser}`, 
                embeds: [dmEmbed], 
                components: [row] 
            });
            const successEmbed = new EmbedBuilder()
                .setDescription(`**Successfully summoned ${targetUser} to this channel.**`)
                .setColor('#FF0000');
            return interaction.editReply({ content: null, embeds: [successEmbed] });
        } catch (error) {
            console.error(error);
            return interaction.editReply({
                content: `**Could not DM this user. Their DMs might be closed.**`
            });
        }
    }
};
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM