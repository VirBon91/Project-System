// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, PermissionsBitField, MessageFlags } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('حذف عدد من الرسائل')
        .addIntegerOption(Option => Option
            .setName(`number`)
            .setDescription(`عدد الرسائل`)
            .setRequired(true))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageMessages),
    async execute(interaction) {
        try {
            const number = interaction.options.getInteger(`number`);

            if (number > 100) {
                return interaction.reply({ 
                    content: `**You cannot delete more than __100__ messages.**`, 
                    flags: [MessageFlags.Ephemeral] 
                });
            }

            await interaction.reply({ 
                content: `**Deleting messages ...**`,
                flags: [MessageFlags.Ephemeral] 
            });

            const deletedMessages = await interaction.channel.bulkDelete(number, true);

            if (deletedMessages.size === 0) {
                return interaction.editReply({ content: `**No messages were deleted (probably because the messages are very old and exceed 14 days).**` });
            }

            await interaction.editReply({ content: `**\`\`\`${deletedMessages.size} messages have been deleted\`\`\`**` });

            setTimeout(() => {
                interaction.deleteReply().catch(() => {});
            }, 1500);

        } catch (error) {
            console.log(error);
            const errorMsg = `**An error occurred; please ensure the messages are not too old or I have permissions.**`;
            
            if (interaction.replied || interaction.deferred) {
                await interaction.editReply({ content: errorMsg });
            } else {
                await interaction.reply({ content: errorMsg, flags: [MessageFlags.Ephemeral] });
            }
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM