// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('user')
        .setDescription('معلومات تفصيلية عن حسابك أو شخص آخر')
        .addUserOption(Option => Option
            .setName(`user`)
            .setDescription(`الشخص`)
            .setRequired(false)),
    async execute(interaction) {
        await interaction.deferReply();
        try {
            const member = interaction.options.getMember('user') || interaction.member;
            if (!member) {
                return interaction.editReply({ content: '**Could not find this member in the server.**' });
            }

            const user = await member.user.fetch({ force: true });
            
            const joinedDiscord = Math.floor(user.createdTimestamp / 1000);
            const joinedServer = Math.floor(member.joinedTimestamp / 1000);
            
            const roles = member.roles.cache
                .filter(r => r.id !== interaction.guild.id)
                .sort((a, b) => b.position - a.position)
                .map(r => r)
                .slice(0, 10);
                
            const rolesDisplay = roles.length > 0 ? roles.join(" ") : "لا توجد رتب";
            const avatarUrl = user.displayAvatarURL({ dynamic: true, size: 4096 });
            const bannerUrl = user.bannerURL({ dynamic: true, size: 4096 });
            
            const embed = new EmbedBuilder()
                .setAuthor({ name: user.tag, iconURL: avatarUrl })
                .setThumbnail(avatarUrl)
                .setColor('#FF0000')
                .addFields(
                    { name: 'ID', value: `${user.id}`, inline: true },
                    { name: 'Nickname', value: `${member.nickname || "None"}`, inline: true },
                    { name: 'Bot?', value: `${user.bot ? "Yes" : "No"}`, inline: true },
                    { name: 'Joined Discord', value: `<t:${joinedDiscord}:F> (<t:${joinedDiscord}:R>)`, inline: false },
                    { name: 'Joined Server', value: `<t:${joinedServer}:F> (<t:${joinedServer}:R>)`, inline: false },
                    { name: `Roles [${member.roles.cache.size - 1}]`, value: rolesDisplay, inline: false }
                )
                .setFooter({ text: `Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });
            
            if (bannerUrl) {
                embed.setImage(bannerUrl);
            }
            
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setStyle(ButtonStyle.Link)
                        .setLabel("Avatar")
                        .setURL(avatarUrl)
                );
            
            if (bannerUrl) {
                row.addComponents(
                    new ButtonBuilder()
                        .setStyle(ButtonStyle.Link)
                        .setLabel("Banner")
                        .setURL(bannerUrl)
                );
            }
            
            return interaction.editReply({ embeds: [embed], components: [row] });
        } catch (error) {
            console.error(error);
            return interaction.editReply({ content: '**An error occurred**' });
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM