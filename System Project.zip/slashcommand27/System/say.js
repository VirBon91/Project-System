// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, PermissionsBitField, MessageFlags } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('say')
        .setDescription('قول كلام')
        .addStringOption(Option => Option
            .setName(`sentence`)
            .setDescription(`الجملة`)
            .setRequired(true))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageMessages),
    async execute(interaction) {
        const sentence = interaction.options.getString(`sentence`);
        await interaction.channel.send({ content: `${sentence}` });
        await interaction.reply({ 
            content: `**Your message has been sent**`, 
            flags: [MessageFlags.Ephemeral] 
        });
        setTimeout(() => {
            interaction.deleteReply().catch(() => {});
        }, 1500);
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM