// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, PermissionsBitField, MessageFlags } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('mute')
        .setDescription('اعطاء ميوت لشخص او ازالته (نظام رتبة Muted)')
        .addUserOption(Option => Option
            .setName(`member`)
            .setDescription(`الشخص`)
            .setRequired(true))
        .addStringOption(Option => Option
            .setName(`give_or_remove`)
            .setDescription(`الاعطاء ام السحب`)
            .setRequired(true)
            .addChoices(
                { name: `Give`, value: `Give` },
                { name: `Remove`, value: `Remove` }
            ))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageRoles),

    async execute(interaction) {
        await interaction.deferReply();

        try {
            const member = interaction.options.getMember(`member`);
            const action = interaction.options.getString(`give_or_remove`);

            if (!member) {
                return interaction.editReply({ content: `**Member not found.**` });
            }
            let role = interaction.guild.roles.cache.find(ro => ro.name.toLowerCase() === "muted");

            if (!role) {
                try {
                    role = await interaction.guild.roles.create({
                        name: `Muted`,
                        permissions: [],
                        color: '#000000',
                        reason: 'Muted role created by bot'
                    });

                    interaction.guild.channels.cache.forEach(async (channel) => {
                        try {
                            await channel.permissionOverwrites.create(role, {
                                SendMessages: false,
                                Speak: false,
                                AddReactions: false
                            });
                        } catch (err) {
                        }
                    });
                } catch (error) {
                    return interaction.editReply({ content: `**I couldn't create the Muted role (Missing Permissions).**` });
                }
            }

            if (!role.editable) {
                return interaction.editReply({ content: `**I cannot manage the 'Muted' role (It is higher than my role).**` });
            }

            if (action === "Give") {
                if (member.roles.cache.has(role.id)) {
                    return interaction.editReply({ content: `**The member is already muted.**` });
                }
                await member.roles.add(role);
                return interaction.editReply({ content: `**The mute was successfully given to the person.**` });
            }

            if (action === "Remove") {
                if (!member.roles.cache.has(role.id)) {
                    return interaction.editReply({ content: `**This person does not have a mute to remove.**` });
                }
                await member.roles.remove(role);
                return interaction.editReply({ content: `**The mute was successfully removed from the person.**` });
            }

        } catch (error) {
            console.error(error);
            return interaction.editReply({ content: `**An error occurred (Check Permissions).**` });
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM