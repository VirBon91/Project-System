// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, PermissionsBitField, MessageFlags } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('timeout')
        .setDescription('اعطاء تايم اوت لشخص (ضع الوقت 0 لإزالة التايم اوت)')
        .addUserOption(Option => Option
            .setName(`member`)
            .setDescription(`الشخص`)
            .setRequired(true))
        .addIntegerOption(Option => Option
            .setName(`time`)
            .setDescription(`الوقت بالدقائق (0 للإزالة)`)
            .setRequired(true)
            .setMinValue(0))
        .addStringOption(Option => Option
            .setName(`reason`)
            .setDescription(`السبب`)
            .setRequired(false))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ModerateMembers),

    async execute(interaction) {
        const member = interaction.options.getMember(`member`);
        const time = interaction.options.getInteger(`time`);
        const reason = interaction.options.getString(`reason`) || "No reason provided";

        if (!member) {
            return interaction.reply({ 
                content: `**Member not found.**`, 
                flags: [MessageFlags.Ephemeral] 
            });
        }

        if (!member.moderatable) {
            return interaction.reply({ 
                content: `**I cannot timeout this user (Role is higher or equal to mine).**`, 
                flags: [MessageFlags.Ephemeral] 
            });
        }

        try {
            if (time === 0) {
                await member.timeout(null, reason);
                return interaction.reply({ content: `**The timeout has been removed successfully.**` });
            } else {
                await member.timeout(time * 60 * 1000, reason);
                return interaction.reply({ content: `**The timeout was successfully given to the person for ${time} minutes.**` });
            }
        } catch (error) {
            console.error(error);
            return interaction.reply({ 
                content: `**An error occurred (Check my permissions or limits).**`, 
                flags: [MessageFlags.Ephemeral] 
            });
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM