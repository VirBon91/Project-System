// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('send')
        .setDescription('لارسال رسالة لشخص ما')
        .addUserOption(Option => Option
            .setName(`user`)
            .setDescription(`الشخص المراد الارسال له`)
            .setRequired(true))
        .addStringOption(Option => Option
            .setName(`message`)
            .setDescription(`الرسالة المراد ارسالها`)
            .setRequired(true))
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageMessages),
    async execute(interaction) {
        await interaction.deferReply();
        try {
            const user = interaction.options.getUser(`user`);
            const message = interaction.options.getString(`message`);

            const embed = new EmbedBuilder()
                .setTitle('New Message')
                .setDescription(`\`\`\`${message}\`\`\``)
                .setColor('#FF0000');

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('server_info')
                    .setLabel(`${interaction.guild.name}`)
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true)
            );

            await user.send({ embeds: [embed], components: [row] });

            return interaction.editReply({ content: `**The message was sent to the member.**` });
        } catch (error) {
            return interaction.editReply({ content: `**I was unable to send it to the person.**` });
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM