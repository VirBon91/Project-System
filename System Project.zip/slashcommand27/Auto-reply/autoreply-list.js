const {ChatInputCommandInteraction , Client , SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const one4allDB = new Database("/Json-db/Bots/one4allDB.json")
module.exports ={
    adminsOnly:true,
    data: new SlashCommandBuilder()
    .setName('autoreply-list')
    .setDescription('لرؤية جميع الردود'),
    async execute(interaction, client) {
        try {
            await interaction.deferReply();
            const word = interaction.options.getString(`word`)
            const reply = interaction.options.getString(`reply`)
            const data = await one4allDB.get(`replys_${interaction.guild.id}`);
            if(data){
                if(data.length > 0){
                    const embed = new EmbedBuilder()
                                            .setTitle('All automatic replies')
                                            .setThumbnail(interaction.guild.iconURL({dynamic : true}))
                                            .setAuthor({name : interaction.client.user.username , iconURL : interaction.client.user.displayAvatarURL({dynamic : true})})
                                            .setFooter({text : `Requested by : ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})});
                    await data.forEach(async(d) => {
                       const { word , reply } = d;
                        embed.addFields(
                        {name : `Word: \`${word}\`` , value : `**Reply:** __${reply}__`}
                       )
                    })
                    embed.addFields({name : `\n` , value : `\`\`\`There is ${data.length} Responses on the server\`\`\``})
                    return interaction.editReply({embeds : [embed]})
                }else{
                    return interaction.editReply({content : `**There are no recorded automated responses for this server.**`})
                }
            }else{
                return interaction.editReply({content : `*There are no recorded automated responses for this server.**`})
            }
        } catch {
            return interaction.editReply({content:`**An error occurred. Contact the developers.**`})
        }
    }
}