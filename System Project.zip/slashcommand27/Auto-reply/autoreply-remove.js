// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM
const {ChatInputCommandInteraction , Client , SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const one4allDB = new Database("/Json-db/Bots/one4allDB.json")
module.exports ={
    adminsOnly:true,
    data: new SlashCommandBuilder()
    .setName('autoreply-remove')
    .setDescription('لازالة رد تلقائي')
    .addStringOption(Option => Option
                            .setName(`word`)
                            .setDescription(`الكلمة`)
                            .setRequired(true)),
    async execute(interaction, client) {
        try {
            await interaction.deferReply();
            const word = interaction.options.getString(`word`)
            const replysCheck = await one4allDB.get(`replys_${interaction.guild.id}`);
            if(replysCheck){
                    const data = await replysCheck.find((r) => r.word == word)
                    if(data){
                        const replysFiltered = replysCheck.filter(r => r.word !== word)
                        await one4allDB.set(`replys_${interaction.guild.id}` , replysFiltered)
                        return interaction.editReply({content : `**The auto reply has been deleted \`${word}\`**`});
                    }else{
                        return interaction.editReply({content : `**There is no reply using that word. \`${word}\`**`});
                    }
            }else{
                return interaction.editReply({content : `**There is no reply using that word. \`${word}\`**`});
            }
        } catch {
            return interaction.editReply({content:`**An error occurred. Contact the developers.**`})
        }
    }
}
// YouTube: https://www.youtube.com/@VirBon91
// Discord: https://discord.gg/pSU8D9pDhM